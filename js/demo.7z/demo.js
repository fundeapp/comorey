const pkg='jdpa.reyesvete',filename='index.js';
//db
var db=null;
var resF=null;
var dbName='data';
let sch='schemas.sql';
let aft='after.js';
let vrs='';
let onDbLoaded=null;
//tables();
function tables() {
	console.log('loading tables');
	readFile(sch,function(data){
		querySql(data,function(endTime){
			if(onDbLoaded!=null){
				onDbLoaded();
			}
			console.log('tables loaded');
		});
	});
}
function loadBackup(){

}

function querySql(sql,onfinish){
	try {
		html5sql.openDatabase(dbName, "", 100*1024*1024,function(){
			var startTime = new Date();
			html5sql.process(
				sql,
				function(){var endTime =((new Date - startTime) / 1000); console.log("Succes in: " +endTime + "s"); onfinish(endTime);},
				function(error, failingQuery){
					console.log("query Error: "+sql+" -> " + error.message);
				});
		});
	} catch (error) {
		console.log("query Error: "+sql+" -> " + error.message);
	}
}

function errorDB(transaction, error) {
	console.log("Error processing SQL -> Code :"+error.code +" -> Message : "+error.message);
}

function successDB() {
}

function query(sql,funcion,errorT){
	console.log(sql);
	let et=function(transaction, error){
		console.log("Error processing SQL -> Code :"+error.code +" -> Message : "+error.message);
		if(errorT!=null){
			errorT(error);
		}
	}
	if(db==null){
		db = window.openDatabase(dbName,vrs, "", 100*1024*1024);
	}
	if(sql.indexOf('create')!=-1){
		db.transaction(function(tran){tran.executeSql(sql);}, et, successDB);
	}else if(sql.indexOf('insert')!=-1|sql.indexOf('update')!=-1|sql.indexOf('delete')!=-1){
		db.transaction(function(tran){tran.executeSql(sql, [], function(tx,rs){
			if(funcion!=null){
				try{
					funcion(rs.rowsAffected,rs.insertId);
				}catch(e){
					funcion(rs.rowsAffected,null);
				}
			}
		}, et);}, et, successDB);   
	}else{
		db.transaction(function(tran){tran.executeSql(sql, [], function(tx,rs){
			let data=[];
			for(let i=0;i<rs.rows.length;i++){
				data.push(rs.rows.item(i));
			}
			funcion(data);
		}, et);}, et, successDB);    
	}
}
function readFile(path,funcion){
	jQuery.get(path, funcion);
}
function invertStack(){
	var a=0;
	var b=pila.length-1;
	while(a<b){
		var aux=pila[a];
		pila[a]=pila[b];
		pila[b]=aux;
		a++;
		b--;
	}
}

//app
var isMobile = (navigator.userAgent.match(/iPad|iPhone|android/i) != null);
var tema_s='';
var color_s='';

var stylesheet = document.createElement('style');
var customStyle = document.createElement('style');
document.head.appendChild(stylesheet);
document.head.appendChild(customStyle);
var isFlat=true;
var globalTheme = 'light';
var globalBarsStyle = 'empty';
var globalCustomColor = '';
var globalCustomProperties = '';
var colors = ['red','#ff3b30','green','#4cd964','blue','#2196f3','pink','#ff2d55','yellow','#ffcc00','orange','#ff9500','purple','#9c27b0','deeppurple','#673ab7','lightblue','#5ac8fa','teal','#009688','lime','#cddc39','deeporange','#ff6b22','gray','#8e8e93','white','#ffffff','black','#000000'];

var colorsTheme=[{name:'Red',back:'#f44336',color:'white'},{name:'Pink',back:'#e91e63',color:'white'},{name:'Purple',back:'#9c27b0',color:'white'},
{name:'Deep Purple',back:'#673ab7',color:'white'},{name:'Indigo',back:'#3f51b5',color:'white'},{name:'Blue',back:'#2196f3',color:'white'},
{name:'Light Blue',back:'#03a9f4',color:'white'},{name:'Cyan',back:'#00bcd4',color:'white'},
{name:'Teal',back:'#009688',color:'white'},{name:'Green',back:'#4caf50',color:'white'},{name:'Light Green',back:'#8bc34a',color:'white'},
{name:'Lime',back:'#cddc39',color:'white'},{name:'Yellow',back:'#ffeb3b',color:'black'},{name:'Amber',back:'#ffc107',color:'white'},
{name:'Orange',back:'#ff9800',color:'white'},{name:'Deep Orange',back:'#ff5722',color:'white'},{name:'Brown',back:'#795548',color:'white'},
{name:'Grey',back:'#9e9e9e',color:'white'},{name:'Blue Gray',back:'#607d8b',color:'white'}];

var token='pk.eyJ1Ijoibm9saW1pdHM0d2ViIiwiYSI6ImNqcXA4NTdmczBocm8zeG13Zm1zNTdyeDAifQ.HoJgmqQ_uH4zLyNJmiY98A';
var minero=[-63.23311342708962,-17.117668875177515];
var scz=[-63.182134292344756,-17.783295857478013];
var markerStyle = document.createElement('style');
document.head.appendChild(markerStyle);
markerStyle.innerHTML=`div.marker-demo{background:black; color:white; } i.marker-demo{color:black; } `;

var $$ = Dom7;

function updateI(){
	if (Framework7.device.ios) {
		$('#root-drawer').css('padding-top','0em');
		$('#main-title').css('left','0px');
	}
}


function initView(){
	var mainView = app.views.create('.view');
	return mainView;
}
function hideDrawer(){
	app.panel.close('panel', true);
}
function initTable(){
	var mainTable = app.dataTable.create({el:'.data-table'});
}
function refreshPanel(ele,on,swipe){
	var panel;
	panel = app.panel.create({
		el: ele,
		swipeActiveArea:15,
		swipe: swipe,
		on:on
	});
	if(window.innerWidth>992&!$(ele).hasClass('panel-right')){
		$(ele).addClass('panel-visible-by-breakpoint');
		$('.view-main').css('margin-left','240px');
		$(ele).css('width','240px');
		$(ele).css('transform','none');
		$(ele).css('display','block');
	}
	return panel;
}

function initRoot(){
	var view = app.views.create('.dinamic',{url:'/'});
	return view;
}
var curCal=null;
function refreshDate(id){
	curCal = app.calendar.create({
		inputEl: '#'+id,
		openIn: 'customModal',
		header: true,
		footer: true,
		backdrop:true,
		closeByBackdropClick:true,
		closeOnSelect:true,
		footer: false,	
		dateFormat: 'yyyy-mm-dd',
		monthNames:['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto' , 'Septiembre' , 'Octubre', 'Noviembre', 'Diciembre'],
		monthNamesShort: [ 'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic' ],
		dayNames:[ 'Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado' ],
		dayNamesShort:[ 'Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb' ],
		headerPlaceholder:'Seleccionar',
		yearSelector:true,
		monthSelector:true,
		toolbarCloseText:'OK',
		on: {
			open: function () {
			},
			opened: function(){
				click('.calendar-close:last',function(){
					//alert('#'+id);
					//alert(curCal.value);
					//$('.calendar:last').addClass('modal-out');
					//app.calendar.close('.calendar');
					//curCal.close();
					curCal.modal.close();
				});
			},
			closed: function(){
			}
		}
	});
}
function initPage(){
	var view = app.views.create('.page-view',{url:'/'});
	return view;
}
function openSelect(){
	var ss = $('<a class="item-link smart-select smart-select-init" id="myselect" data-open-in="popover"> <select name="fruits"><option value="apple" selected>Apple</option><option value="pineapple">Pineapple</option><option value="pear">Pear</option><option value="orange">Orange</option></select><div class="item-content"><div class="item-inner"><div class="item-title">Fruit</div></div></div></a>');
	app.smartSelect.open(ss);
}
function clearSelect(item){
	var afts=$(item).find('.item-after').length;
	if(afts==2){
		$(item).find('.item-after').eq(afts-1).remove();
	}
}
function loadPanel(title,content){
	let cnt=`
	<div class="view-panel">
	<div class="page">
	<div class="navbar">
	<div class="navbar-bg"></div>
	<div class="navbar-inner">
	<div class="title">${title}</div>
	</div>
	</div>
	${content}
	</div>
	</div>`;
	querySelector('#right-drawer').innerHTML=cnt;
	var view = app.views.create('.view-panel',{url:'/'});
	paneld.open();
}
var pop;
function showPop(title,content,after,onClose,rightButtons,drawer){
	let rbtns=rightButtons?rightButtons.map(e=>`<a id="${e.id}" class="link ${e.class?e.class:''}"><i class="material-icons">${e.icon}</i></a>`).join(''):'';
	let cnt=`
	<div class="popup popup-tablet-fullscreen">
	<div class="view-pop">
	<div class="page">
	<div class="navbar">
	<div class="navbar-bg"></div>
	<div class="navbar-inner">
	${drawer?`<div class="left"> <a class="link icon-only panel-open hide-on-large-only" data-panel=".panel-pop"> <i class="icon material-icons">menu</i> </a> </div>`:''}
	<div class="title multil">${title}</div>
	<div class="right">
	${rbtns}
	<a href="#" class="link popup-close backer-button"><i class="material-icons">close</i></a>
	</div>
	</div>
	</div>
	${content}
	</div>
	</div>
	${drawer?`<div class="panel-backdrop"></div> <div class="panel panel-left panel-cover panel-pop" id="drawer_panel_pop"> <div class="view"> <div class="page" id="root-drawer-pop"> <div id="main-drawer-pop" class="page-content main-drawer" style="overflow:auto"> <div class="drawer-top" style="width:100%;height:9em;position:relative"> </div> </div> </div> </div> </div>`:''}
	</div>`;
	pop=app.popup.create({content:cnt,on:{close:onClose,opened:function(){
		var view = app.views.create('.view-pop',{url:'/'});
		if(drawer){
			refreshPanel('.panel-pop',{open: function () {
				let newz=parseInt($('.popup:last').css('z-index'))+1;
				$('.panel-pop:last').css('z-index',newz);
				$('.panel-backdrop').css('z-index',newz);
			},close:function(){
				$('.panel-backdrop').css('z-index','');
			}});
		}
		after(pop);
	}}});
	pop.open();
}
function queryForeach(selector,funcion){
	document.querySelectorAll(selector).forEach(funcion);
}
function prepareSearch(rootForHide,elementForSearch){
	console.log(`rootForHide = ${rootForHide},elementForSearch = ${elementForSearch}`);
	var input=$('[type=search]:last');
	input.unbind('keyup').bind('keyup',function(){
		$('span.keyed').each(function(){
			this.outerHTML=this.innerHTML;	
		});
		let key=this.value.toLowerCase();
		$(`.${rootForHide}`).show();
		if(key==''){
			return;
		}else{
			$(`.${rootForHide}`).each(function(){
				let index=this.querySelector(`.${elementForSearch}`).innerHTML.toLowerCase().indexOf(key);
				if(index==-1){
					$(this).hide();
				}else{
					let fromKey=this.querySelector(`.${elementForSearch}`).innerHTML.substring(index,index+key.length);
					this.querySelector(`.${elementForSearch}`).innerHTML=this.querySelector(`.${elementForSearch}`).innerHTML.replace(fromKey,`<span class="keyed pulser">${fromKey}</span>`);
				}
			});
		}
	});
	$('.searchbar-disable-button:last').unbind('click').bind('click',function(){
		$(this).removeClass('backer-button');
		$('.input-clear-button:last').click();
		$(this).parents('.searchbar-expandable').removeClass('searchbar-enabled');
		setTimeout(function(){
			input.trigger('blur');
		},500);
	});
	$('.searchbar-enable:last').unbind('click').bind('click',function(){
		setTimeout(function(){
			input.trigger('focus');
		},500);
		$('.searchbar-disable-button:last').addClass('backer-button');
		$('.searchbar').toggleClass('searchbar-enabled');
	});
	$('.input-clear-button:last').bind('click',function(){
		$(input.parents('form').attr('root-for-hide')).show();
	});
	$('.searchbar-enable:last').show();
	$('.searchbar-expandable:last').show();
}
function hideDialog(onfinish){
	$('.custom-modal-backdrop.is-dialog:last').removeClass('backdrop-in');
	$('.calendar-modal:last').addClass('modal-out');
	setTimeout(function(){$('.calendar-modal:last').removeClass('modal-in modal-out');$('.calendar-modal:last').remove();$('.custom-modal-backdrop.is-dialog:last').remove();if(onfinish!=null)onfinish(); }, 500);
}
function showDialog(title,content,positive,before,after,nocancel){
	var dialogs=$('.view-dialog').length;
	$('#app').append('<div class="custom-modal-backdrop is-dialog" style="background:rgba(0,0,0,.25)"></div>');
	$('#app').append('<div class="view-dialog view-dialog'+dialogs+' view calendar calendar-modal dialogo" data-name="dialog-view" style="height:auto;"></div>');
	var view = app.views.create('.view-dialog'+dialogs,{url:'/'});
	$('.view-dialog').last().append(`<div class="calendar-header" style="padding: 0px 12px;"><div class="calendar-selected-date multil">${title}</div></div><div class="calendar-months block" style="padding: .75em; max-height: 70vh; overflow-y: auto; display: initial; margin: 0em;"><div class="row">${content}</div></div><div class="calendar-footer" style="background:transparent"><button class="button backer-button di_no multil" style="Width:108px;color:red !important;">Cancel</button><button class="button di_si multil" style="Width:108px;color:blue !important">${positive}</button></div>`);
	if(before!=null){
		before();
	}
	nocancel?$('.di_no:last').remove():$('.di_no:last').click(()=>{hideDialog()});
	$('.di_si:last').click(after);
}

function showSDialog(title,content,positive,before,after,nocancel){
	showDialog(title,content,positive,function(){
		$('.view-dialog').last().attr('data-val','ok');
		$('.view-dialog').last().attr('style','max-width:var(--f7-calendar-modal-max-width);height:auto');
		if(before!=null){
			loadFunction(before);  
		}
	},after,nocancel);
}
function showMessage(title,msg){
	showSDialog(title,'<span class="multil">'+msg+'<span>','Ok',function(){
		$('#di_no').hide();
	},function(){
		hideDialog();
	});
	prepare();
}
function showConfirm(msg,accept){
	showSDialog('Confirmar','<div class="col s12"><span class="multil">'+msg+'<span></div>','Aceptar',function(){
	},function(){
		loadFunction(accept);
	});
	prepare();
}
function showConfirmDelete(msg,accept){
	showSDialog('Confirmar','<div class="col-100"><span class="multil">'+msg+'<span></div><div class="col-100"><textarea id="obs" type="text" class="input uper resizable hide multil" label="Motivo"></textarea></div>','Aceptar',function(){
	},function(){
		loadFunction(accept);
	});
	prepare();
}
function showProgress(){
	$('#app').append('<div class="custom-modal-backdrop backdrop-in showprogress" style="text-align: center;"><div class="elevation-6" style="margin:1em;padding: 1em;top: 40%;position: relative;background:var(--f7-timeline-item-inner-bg-color);"><h3 id="textLoading" class="multil">Procesando...</h3><p><span class="progressbar-infinite" style="height:10px"></span> </p></div></div>');
	refresh();
}
function prepare(onfinish){
	refresh(function(){
		$('.custom-modal-backdrop.is-dialog').addClass('backdrop-in');
		setTimeout(function(){
			$('.calendar-modal:last').addClass('modal-in');
			if(onfinish)onfinish();
		}, 100);
	});
}
function hideProgress(){
	$('.custom-modal-backdrop.showprogress').remove();
}
function openMenu(ele,items,funcion){
	var height=$(ele).height();
	var top=$(ele).offset().top;
	var cad=`<div id="popope" target-top="${top}" target-height="${height}" class="popover"><div class="popover-inner"><div class="list"><ul>`;
	for(var i=0;i<items.length;i++){
		cad+='<li><a class="list-button item-link popover-close multil" data-index="'+i+'">'+items[i]+'</a></li>';
	}
	cad+='</ul></div></div></div>';
	var menu = app.popover.create({
		targetEl: ele,
		content: cad,
		closeByBackdropClick:true,
		on:{
			opened:function(){
				refresh();
			}
		}
	});
	menu.open();
	$('.popover-close').unbind('click').click(function(){
		funcion(parseInt($(this).attr('data-index')));
	});
	setTimeout(function(){
		$('.popover-backdrop').click(function(){
			app.popover.close('#popope');
		});
	},1000);
}

function notify(icon,appname,when,title,msg){
	var notificationFull = app.notification.create({
		icon: '<i class="material-icons">'+icon+'</i>',
		title: appname,
		titleRightText: when,
		subtitle: title,
		text: msg,
		closeButton: true,
	});
	notificationFull.open();
}

function show(msg,cp){
	var pos='';
	if(isMobile){
		pos='bottom';
	}else{
		pos='top';
	}
	pos='top';
	trans([msg,'Cerrar'],function(res){
		var toast = app.toast.create({
			text: res[0],  
			closeTimeout: 2000,
			closeButton: true,
			closeButtonText: res[1],
			closeButtonColor: 'yellow',
			position:pos,
			on: {
				closeButtonClick: function () {
					clipBoard(cp?cp:msg);
				},
			}
		});
		toast.open();
	});
}
function show1(msg){
	var pos='';
	if(isMobile){
		pos='bottom';
	}else{
		pos='top';
	}
	pos='top';
	var toast = app.toast.create({
		text: msg,  
		closeTimeout: 2000,
		closeButton: true,
		closeButtonText: 'Cerrar',
		closeButtonColor: 'red',
		position:pos
	});
	toast.open();
}
function clipBoard(textToCopy) {
	var myTemporaryInputElement = document.createElement("input");
	myTemporaryInputElement.type = "text";
	myTemporaryInputElement.value = textToCopy;
	document.body.appendChild(myTemporaryInputElement);
	myTemporaryInputElement.select();
	document.execCommand("Copy");
	document.body.removeChild(myTemporaryInputElement);
}

function showPhoto(photos,index){
	var photoBrowser = app.photoBrowser.create({
		photos: photos,
		theme: 'dark',
		type: 'popup',
		navbarOfText:'de'
	});
	index = typeof index !== 'undefined' ? index : 0;
	photoBrowser.open(index);
}
function openCamera(width,height,funcion){
	var content=`<video class="camera hide" style="width: 100%;height: 100%;"></video><div class="fab fab-center-bottom" style="position: fixed; "> <a id="capture_camera"> <i class="icon material-icons white-text">camera</i> </a> </div><div class="fab fab-right-bottom" style="position: fixed;"> <a id="switch_camera"> <i class="icon material-icons white-text">camera_rear</i> </a> </div>`;
	showPop('Cámara',content,function(){
		var loadCamera=function(){
			if (navigator.getUserMedia) {
				switchCam(width,height,funcion);
				click('#switch_camera',function(){
					$('.camera:last').addClass('hide');
					switchCam(width,height,funcion);
				});
			} else {
				show("No se puede usar la Cámara en este Dispositivo :(");
				console.log("No media available");
			}
		}
		if(isApp){
		}else{
			loadCamera();
		}
	},dispose);
}

function dispose(){
	if(window.localStream!=null){
		localStream.getTracks().forEach( (track) => {
			track.stop();
		});
	}
}
function switchCam(width,height,funcion){
	dispose();
	var front=$('.camera:last').attr('data-val');
	if(isApp|isMobile){
		if(front==null){
			front=0;
		}
	}else{
		$('#switch_camera i').parent().hide();
		front=1;
	}
	front==0?$('#switch_camera i').text('camera_front'):$('#switch_camera i').text('camera_rear');
	front==0?$('.camera:last').removeClass('front'):$('.camera:last').addClass('front');
	var video = document.querySelector('video');
	navigator.getUserMedia({audio: false,video:{facingMode: (front==1? "user" : "environment"),width: { min: 1024, ideal: 1280, max: 1920 }, height: { min: 776, ideal: 720, max: 1080 }}}, function(stream) {
		video.srcObject = stream;
		window.localStream = stream;
		video.onloadedmetadata = function(e) {
			let vheight = this.videoHeight;
			let vwidth = this.videoWidth;
			video.play();
			$('.camera:last').removeClass('hide');
			click('#capture_camera',function(){
				showProgress();
				var canvas = document.createElement('canvas');
				canvas.width = vwidth;
				canvas.height = vheight;
				var ctx = canvas.getContext('2d');
				var video = document.querySelector('video');
				ctx.drawImage(video, 0, 0, vwidth, vheight);
				var img = new Image;
				img.onload = function() {
					var iw=img.width;
					var ih=img.height;
					var scale=Math.min((width/iw),(height/ih));
					var iwScaled=iw*scale;
					var ihScaled=ih*scale;
					canvas.width=iwScaled;
					canvas.height=ihScaled;
					let posX=0;
					ctx.save();
					if(front==1){
						posX=-iwScaled;
						ctx.scale(-1, 1);
					}
					ctx.drawImage(img,posX,0,iwScaled,ihScaled);
					ctx.restore();
					if (typeof(funcion) === "function") {hideProgress(); funcion(canvas.toDataURL("image/jpeg",0.5));pop.close();};
				}
				img.src = canvas.toDataURL();
				dispose();
				$('.backer-button:last').click();
			});
		};
	}, function(e){
		console.log("Error:" + e);
	});
	$('.camera:last').attr('data-val',front==1?0:1);
}
function getIcon(icon,clase){
	if(clase==null){
		clase='';
	}
	if(mdicons.indexOf(icon)!=-1){
		return '<i class="material-icons '+clase+'">'+icon+'</i>';
	}else{
		return '<i class="material-icons '+clase+'">add</i>';
	}
}
function getMIcon(icon){
	return '<i class="material-icons">'+icon+'</i>';
}
function getF7Icon(icon){
	return '<i class="f7-icons">'+icon+'</i>';
}

//init
$(document).ready(function(){
	String.prototype.replaceAt=function(index, replacement) {
		return this.substr(0, index) + replacement+ this.substr(index + replacement.length);
	}
	refresh();
	refreshDrawer();
});

function setId(data){
	id=data;
}
function getId(){
	return id;
}

function getSesion(value){
	return sessionStorage.getItem(value);
}

function loadFunction(funcToExecute) {
	funcToExecute(); 
}

function click(ele,funcion){
	$(ele).unbind('click').click(funcion);
}
function refreshDrawer(){
	$('.acordeon__content').each(function(){
		var content = $(this);
		var count=$(this).find('a').length;
		content.css('margin-top', '-'+(count*48)+'px');
	});
	$(document.body).on('click', '.acordeon__button', function(){
		if($(this).parent('.acordeon').hasClass('acordeon_opened')){
			$(this).parent('.acordeon').removeClass('acordeon_opened');
		}else{
			$('.acordeon').each(function(){
				$(this).removeClass('acordeon_opened');
			});
			$(this).parent('.acordeon').addClass('acordeon_opened');
		}
	});
}

function hideSearch(){
	$('#search-btn').hide();
}
function showSearch(){
	$('#search-btn').removeClass('hide');
}
function initListen(ele){
	if(ele.querySelector('i').innerHTML=='stop'){
		if(recognizer)recognizer.stop();
		return;
	}
	if(recognizer)recognizer.stop();
	if(isApp){
		let input=ele.getAttribute('input');
		
		return;
	}
	if (!('webkitSpeechRecognition' in window)) {
		show('El reconocimiento de voz no está disponible en este dispositivo :(');
		ele.querySelector('i').innerHTML='mic';
		$(ele).removeClass('pulser');
	} else {
		let input=ele.getAttribute('input');
		if(recognizer==null){
			recognizer = new webkitSpeechRecognition();
			recognizer.continuous = true;
			recognizer.interimResults = true;
			recognizer.lang = langue;
		}
		let before,after;
		recognizer.onstart = function() {
			$(ele).addClass('pulser');
			ele.querySelector('i').innerHTML='stop';
			before=getVal(input);
		};

		recognizer.onerror = function(event) {
			console.log(event);
			/*openTab(`chrome://flags/#unsafely-treat-insecure-origin-as-secure`);*/
			show('El reconocimiento de voz no está disponible en este dispositivo :(');
			ele.querySelector('i').innerHTML='mic';
			$(ele).removeClass('pulser');
			recognizer.stop();
		};
		recognizer.onend = function() {
			ele.querySelector('i').innerHTML='mic';
			$(ele).removeClass('pulser');
			recognizer.stop();
		};
		recognizer.onresult = function(e) {
			let transcript = e.results[e.resultIndex][0].transcript;
			after=transcript;
			if(isMobile){
				let mobileRepeatBug = (e.resultIndex == 1 && transcript == e.results[0][0].transcript);
				if(!mobileRepeatBug) {
					setVal(input,before==''?uperF(transcript):before+' '+transcript);
					after=before+' '+transcript;
				}
			}else{
				setVal(input,before==''?uperF(transcript):before+' '+transcript);
				if (event.results[e.resultIndex].isFinal) {
					ele.querySelector('i').innerHTML='mic';
					$(ele).removeClass('pulser');
					recognizer.stop();
				}
			}
		};
		recognizer.stop();
		recognizer.start();
	}
}

function trans(words,funcion){
	if(langue=='es'){
		funcion(words);
		return;
	}
	let results=[];
	words.forEach((e,i,a)=>{
		requestFile(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=es&tl=${langue}&dt=t&dj=1&q=${e}`,'json',function(res){
			let trad=res.sentences[0].trans;
			trad=trad[0].toUpperCase()+trad.slice(1);
			results.push(trad);
			if(results.length==words.length){
				if(debug){
					console.log(`in = ${parseString(words)} out = ${results}`);	
				}
				funcion(results);
			}
		});
	});
}

function refresh(onfinish){
	$('.label-container').each(function(){
		var id=$(this).attr('id');
		if(id==null){
			id='';
		}
		var label=$(this).attr('label');
		if(label==null){
			label='';
		}
		$(this).replaceWith('<div id="'+id+'" class="list no-hairlines-md"><ul><li><div class="item-content item-input item-input-with-value"><div class="item-inner" style="width:80%;padding-right: 0px;"><div class="item-title item-floating-label">'+label+'</div><div class="item-input-wrap label-content"> </div></div></div></li></ul></div>');
	});
	$('.buttons').each(function () {
		$(this).removeClass('buttons');
		var text = $(this).text();
		var iconData = $(this).attr('data-icon');
		var iconClass=$(this).attr('icon-class');
		if ($(this).hasClass("float")) {
			$(this).removeClass('float');
			var id=$(this).attr('id');
			if(id==null){
				id='btn'+$(this).index();
			}
			var style=$(this).attr('style');
			var clases=$(this).attr('class');
			if(style==null){
				style='';
			}
			let container=$('<div class="fab '+clases+'" style="'+style+'"> <a id="'+id+'"> <i class="material-icons">'+iconData+'</i> </a> </div>');
			$(this).replaceWith(container);
		} else if ($(this).hasClass("icon")) {
			$(this).removeClass('icon');
			$(this).addClass('link icon-only');
		} else if ($(this).hasClass("normal")) {
			$(this).removeClass('normal');
			$(this).addClass('button button-raised button-fill');
		} else if ($(this).hasClass("flat")) {
			$(this).removeClass('normal');
			$(this).addClass('button button-raised');
		}else if ($(this).hasClass("out")) {
			$(this).removeClass('out');
			$(this).addClass('button button-outline button-raised');
		}
		if(iconData!=null){
			if(iconClass!=null){
				$(this).append('<i class="material-icons ' + iconClass + '">' + iconData + '</i>');
			}else{
				$(this).append('<i class="material-icons">' + iconData + '</i>');
			}
		}
		$(this).removeClass('hide');
	});
	$('input.checkbox').each(function(){
		$(this).removeClass('radio');
		var id = $(this).attr('id');
		var name = $(this).attr('name');
		var value = $(this).attr('value');
		var checked = $(this).attr('checked');
		var clases = $(this).attr('class');
		var w = $(this).width();
		var label=$(this).attr('label');
		var index=$(this).index();
		if(id==null){
			$(this).attr('id','checkbox_'+index);
			id = $(this).attr('id');
		}
		var copy = $(this).clone().attr('id', 'new' + id);
		var container = $('<label class="checkbox"/>');
		container.append(copy);
		if(label!=null){
			container.append('<i class="icon-checkbox"/>'+label);
		}else{
			container.append('<i class="icon-checkbox"/>');
		}
		$(this).replaceWith(container);
		$('#new' + id).attr('id', id);
		$('#'+id).addClass(clases);
		loadAttr(id,['checked','value','name'],[checked,value,name]);
		$('#'+id).removeClass('hide');
	});
	$('input[type=password]').addClass('ignore');
	$('.date').addClass('ignore');
	$('.date').addClass('no-clear');
	$('.theme').addClass('ignore');
	$('.place').addClass('ignore');
	$('.icon').addClass('ignore');
	$('.select').each(function () {
		$(this).removeClass('select');
		var id=$(this).index();
		$(this).attr('name',$(this).attr('id'));
		var label = $(this).attr('label');
		$(this).removeAttr('label');
		var html=$(this).parent().html();
		var padr='0';
		if($(this).attr('icon')){
			padr='2em';
		}
		if(label==null){
			label='';
		}
		var container;
		var begin='';
		var end='';
		var withValue='';
		if($(this).val()){
			withValue=' item-input-with-value';
		}
		begin=`<div class="list no-hairlines-md" style="padding-left:${padr};${$(this).hasClass("newer")?'padding-right: 2em;':''}"><i class="material-icons" style="position: absolute; left: 0; top: 38%;">${$(this).attr('icon')}</i><ul><li><div class="item-content item-input ${withValue}"><div class="item-inner">`;
		end=`</div></li></ul>${$(this).hasClass("newer")?`<div class="fab" style="top: 40%;right:0;"> <a id="new_${$(this).attr('id')}" style="width:28px;height:28px;"> <i class="material-icons">add</i></a> </div>`:''}</div>`;
		html+='<div class="item-title item-floating-label multil">'+label+'</div><div class="item-input-wrap"><div class="item-after"></div></div>';
		if ($(this).hasClass("long")) {
			$(this).removeClass('long');
			container=$(begin+'<a class="item-link smart-select smart-select-init no-ripple" style="width:100%" onclick="clearSelect(this)" data-open-in="popup" data-searchbar="true" data-searchbar-placeholder="'+label+'">'+html+'</a>'+end);
		}else{
			container=$(begin+'<a class="item-link smart-select smart-select-init no-ripple" style="width:100%" data-open-in="popover">'+html+'</a>'+end);
		}
		container.find('select').removeClass('hide');
		container.find('select').removeAttr('label');
		$(this).replaceWith(container);
		$(this).css('width', '100%');
	});
	$('.input').each(function () {
		if(!['textarea','input'].includes(this.tagName.toLowerCase())){
			return;
		}
		$(this).removeClass('input');
		var input=this;
		var id=$(this).attr('id');
		var html=$(this).parent().html();
		var label = $(this).attr('label');
		var pad='0';
		var padr='0';
		var button='';
		var withValue='';
		if($(this).attr('icon')){
			padr='2em';
		}
		if($(this).val()){
			withValue=' item-input-with-value';
		}
		let cleartBtn='';
		if ($(this).hasClass("no-clear")|$(this).hasClass("theme")|$(this).hasClass("place")|$(this).hasClass("icon")) {
			$(this).removeClass('no-clear');
		}else{
			cleartBtn=`<div class="fab transparent ${input.getAttribute('id')==null?'':'btn-clear'}" input="${id}" style="top: 0%;right: 0%;"><a style="width:28px;height:28px;" tabindex="-1"> <i class="material-icons">cancel</i></a></div>`;
		}
		if(!$(this).hasClass('ignore')){
			button=`<div class="fab listen" style="top: 40%;right:5%;" input="${id}"> <a style="width:30px;height:30px;"> <i class="material-icons">mic</i></a> </div>`;
			pad='2em';
			$(this).removeClass('ignore');
		}else{
			pad='0';	
		}
		if(label==null){
			label='';
		}
		var container=$(`<div class="list no-hairlines-md" style="padding-left:${padr};padding-right: ${pad}"><i class="material-icons" style="position: absolute; left: 0; top: 45%;">${$(this).attr('icon')}</i><ul><li><div class="item-content item-input ${withValue}"><div class="item-inner"><div class="item-title item-floating-label multil">${label}</div><div class="item-input-wrap">${html}</div></div></div></li></ul>${button}${cleartBtn}</div>`);
		container.find('input').removeClass('hide');
		container.find('textarea').removeClass('hide');
		container.find('input').removeAttr('label');
		container.find('textarea').removeAttr('label');
		container.find('textarea').addClass('resizable');
		$(this).replaceWith(container);
		$(this).css('width', '100%');
		$('#'+id).attr("autocomplete",$('#'+id).attr('type')=='password'?"new-password":'off');
	});
	queryForeach('.fab.listen',(e)=>{e.onclick=function(){initListen(this);}});
	/*longClick('.input-clear-button',function(e){
		let ele=this.parentNode.querySelector('input');
		if(ele==null){
			ele=this.parentNode.querySelector('textarea');
		}
		setVal(ele.getAttribute('id'),'');
		$(`#${ele.getAttribute('id')}`).keyup();
	});*/
	setTimeout(function(){
		/*$('.btn-clear').unbind('long-press').bind('long-press',function(){
			let inp=this.getAttribute('input');
			setVal(inp,'');
		});*/
		queryForeach('.btn-clear',(e)=>{e.addEventListener('long-press',function(){
			let inp=this.getAttribute('input');
			setVal(inp,'');
		})});
		$('.btn-clear').unbind('click').bind('click',function(){
			let inp=this.getAttribute('input');
			if(getVal(inp).trim()==''){
				return;
			}
			let pals=getVal(inp).split(' ');
			pals.pop();
			console.log(pals);
			console.log(pals.join(' '));
			setVal(inp,pals.join(' '));
		});
	},500);
	$('.uper').each(function(){
		this.classList.remove('uper');
		$(this).on('keydown keypress keyup paste input',function(e){
			let cursorp=e.target.selectionStart;
			this.value=this.value.toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
			e.target.setSelectionRange(cursorp,cursorp);
		});
	});
	$('input').each(function(){
		var fire=$(this).attr('fire');
		if(fire!=null){
			$(this).keydown(function(e){
				if(e.which == 13){
					$(fire).trigger('click');
				}
			});
			$(this).removeAttr('fire');
		}
	});
	$('.center-in-parent').each(function () {
		var wp, hp, w, h;
		w = $(this).width();
		wp = $(this).parent().width();
		h = $(this).height();
		hp = $(this).parent().height();
		var difW = ((wp - w) / 2);
		var difH = ((hp - h) / 4);
		$(this).css('left', difW + 'px');
		$(this).css('top', difH + 'px');
		$(this).removeClass('hide');
	});
	$('.date').css('cursor','pointer');
	$('.place').css('cursor','pointer');
	$('.date').each(function(){
		$(this).removeClass('date');
		if($(this).attr('id')==null){
			$(this).attr('id','date_'+Math.floor(Math.random() * 1000) + 1);
		}
		var id=$(this).attr('id');
		if(id!=null){
			refreshDate(id);
		}
	});
	$('.place').attr('readonly',true);
	$('.place').click(function(){
		var id=$(this).attr('id');
		pickPlace(id);
	});
	$('.place').removeClass('place');
	$('input.icon').each(function(){
		$(this).css('cursor','pointer');
		$(this).attr('readonly',true);
		$(this).parent().css('display','flex');
		$('<i class="material-icons" style="width: 30px; height: 20px;margin-top: .25em;"></i>').insertBefore(this);
		$(this).removeClass('icon');
		$(this).click(function(){
			pickIcon(this);
		});
	});
	$('img.show').click(function () {
		var index=$(this).index();
		showPhoto([
		{
			url: $(this).attr('src'),
			caption: $(this).attr('title')
		}]);
	});
	$('*').each(function(){
		var cur=$(this);
		var txt=$(this).attr('tooltip');
		if(txt!=null){
			var iconTooltip = app.tooltip.create({
				targetEl: cur,
				text: txt,
			});
		}
	});
	$('select').each(function(){
		if(!this.multiple){
			$(this).parents('item-content').addClass('item-input-with-value');
		}
		let texts=[];
		let values=getVal($(this).attr('id'));
		if(values==null){
			return;
		}
		this.querySelectorAll('option').forEach(ele=>{if(values.includes(ele.value))texts.push(ele.innerHTML);});
		if($(this).parent().find('.item-after').eq(0).text()==''){
			$(this).parent().find('.item-after').eq(0).text(texts.join(', '));
		}
	});
	$('.multil').each(function(){
		let ele=this;
		ele.classList.remove('multil');
		if(langue=='es'){
			return;
		}
		if(ele.getAttribute('placeholder')!=null){
			trans([ele.getAttribute('placeholder')],function(res){
				ele.setAttribute('placeholder',res);
			});
		}
		trans([ele.innerHTML],function(res){
			ele.innerHTML=res;
		});
	});
	/*$('input').unbind('keyup').on('keyup',function(){
		if(this.value==''){
			$(this).parents('.item-content').removeClass('item-input-with-value');
		}
	});*/
	$('input').each(function(){
		if(['text','password','tel'].includes(this.getAttribute('type'))){
			$(this).on('keydown keypress keyup paste input change',function(event){
				if(this.getAttribute('maxlength')){
					this.value=this.value.substring(0,parseInt(this.getAttribute('maxlength')));
				}
				if(this.getAttribute('deny')==null){
					return;
				}
				let deny=this.getAttribute('deny');
				for (var i = 0; i < deny.length; i++) {
					this.value=this.value.replace(new RegExp(deny.charAt(i),'g'),String.fromCharCode(0));
				}
			});
		}
	});
	$('textarea').each(function(){
		if(['text','password','tel'].includes(this.getAttribute('type'))){
			$(this).on('keydown keypress keyup paste input change',function(event){
				if(this.getAttribute('maxlength')){
					this.value=this.value.substring(0,parseInt(this.getAttribute('maxlength')));
				}
				if(this.getAttribute('deny')==null){
					return;
				}
				let deny=this.getAttribute('deny');
				for (var i = 0; i < deny.length; i++) {
					this.value=this.value.replace(new RegExp(deny.charAt(i),'g'),String.fromCharCode(0));
				}
			});
		}
	});
	$('input.int').attr('type','tel');
	$('input.int').on('keydown keypress keyup paste input', function () {
		this.classList.remove('int');
		$(this).on('keydown keypress keyup paste input',function(event){
			this.value=this.value.replace(/[^0-9]/g, '');
			var max=this.getAttribute('max');
			if(max!=null&this.value!=''){
				if(parseInt(this.value)>(parseInt(max))){
					this.value=parseInt(max);
				}
			}
		});
	});
	$('input.intel').attr('type','tel');
	$('input.intel').on('keydown keypress keyup paste input', function () {
		this.classList.remove('intel');
		$(this).on('keydown keypress keyup paste input',function(event){
			this.value=this.value.replace(/[^0-9-]/g, '');
			var max=this.getAttribute('max');
			if(max!=null&this.value!=''){
				if(parseInt(this.value)>(parseInt(max))){
					this.value=parseInt(max);
				}
			}
		});
	});
	$('input.float').attr('type','tel');
	$('input.float').on('keydown keypress keyup paste input', function () {
		this.classList.remove('float');
		let signed=false;
		if(this.classList.contains('signed')){
			signed=true;
			this.classList.remove('signed');
		}
		$(this).on('keydown keypress keyup paste input',function(event){
			while ( (this.value.split(".").length - 1) > 1 ) {
				this.value=this.value.slice(0, -1);
				if ( (this.value.split(".").length - 1) > 1 ) {
					continue;
				} else {
					return false;
				}
			}
			while ( (this.value.split("-").length - 1) > 1 ){
				this.value=this.value.slice(0, -1);
				if ( (this.value.split("-").length - 1) > 1 ){
					continue;
				} else {
					return false;
				}
			}
			if(signed){
				if(this.value.startsWith('-')){
					this.value=this.value.replace(/[^0-9.-]/g, '');
				}else{
					this.value=this.value.replace(/[^0-9.]/g, '');
				}
			}else{
				this.value=this.value.replace(/[^0-9.]/g, '');
			}
			var int_num_allow = 100;
			var float_num_allow = 100;
			var iof = this.value.indexOf(".");
			if ( iof != -1 ) {
				if ( this.value.substring(0, iof).length > int_num_allow ) {
					this.value='';
					this.getAttribute('placeholder', 'invalid number');
				}
				this.value=this.value.substring(0, iof + float_num_allow + 1);
			} else {
				this.value=this.value.substring(0, int_num_allow);
			}
			var max=this.getAttribute('max');
			if(max!=null&this.value!=''&this.value!=='.'){
				if(parseFloat(this.value)>(parseFloat(max))){
					this.value=parseFloat(max);
				}
			}
			return true;
		});
	});
	if(onfinish){
		onfinish();
	}
}

function centrar() {
	$('.center-in-parent').each(function () {
		var wp, hp, w, h;
		w = $(this).width();
		wp = $(this).parent().width();
		h = $(this).height();
		hp = $(this).parent().height();
		var difW = (wp - w) / 2;
		var difH = ((hp - h) / 2) - 25;
		$(this).css('margin-left', difW + 'px');
		$(this).css('margin-top', difH + 'px');
	});
}
function longClick(ele,funcion){
	$(ele).unbind('taphold').on('taphold',funcion);
}

function loadAttr(id,attrs,values){
	if(values.length==attrs.length){
		for(var i=0;i<attrs.length;i++){
			if(values[i]!=null){
				$('#'+id).attr(attrs[i],values[i]);				
			}
		}
	}else{
		alert('loadAttr function received wrong lengths of arrays');
	}
}
function select(id,value){
	$('#'+id+' option[value='+value+']').attr('selected', 'selected');
}
function setAttr(id,attribute,value){
	$('#'+id).attr(attribute,value);
}
function getAttr(id,attribute){
	return $('#'+id).attr(attribute);
}
function setText(id,text){
	$('#'+id).text(text);
}
function getText(id){
	return $('#'+id).text();
}
function setCss(id,attribute,value){
	$('#'+id).css(attribute,value);
}
function getCss(id,attribute){
	$('#'+id).css(attribute);
}
function addClass(id,clase){
	$('#'+id).addClass(clase);
}
function removeClass(id,clase){
	$('#'+id).removeClass(clase);
}
function querySelector(selector){
	if(document.querySelector(selector)==null){
		console.log(selector+' is undefined');
		return null;
	}
	return document.querySelector(selector);
}
function getVal(id){
	return $('#'+id).val();
}
function setVal(ele,value){
	if(value==null){
		value="";
	}else{
		value=value.toString();
	}
	if(debug){
		console.log(typeof(value));
		console.log(`setVal(${ele},${parseString(value)})`);
	}
	let id=ele;
	ele=querySelector('#'+ele);
	if(ele==null){
		return;
	}
	console.log(ele.tagName.toLowerCase());
	switch(ele.tagName.toLowerCase()){
		case 'input':
		$$(ele).val(value);
		ele.value=value;
		break;
		case 'textarea':
		setText(id,value);
		$$(ele).val(value);
		setTimeout(resizeTextarea,500);
		//resizeTextarea();
		break;
		case 'select':
		ele.querySelectorAll('option').forEach(ele=>ele.removeAttribute('selected'));
		if(ele.multiple){
			if(value!=null){
				ele.querySelectorAll('option').forEach(ele=>value.indexOf(ele.value)!=-1?ele.setAttribute('selected',''):ele.removeAttribute('selected'));
			}
		}else{
			ele.querySelector(`option[value="${value}"]`).setAttribute('selected', 'selected');
			ele.parentNode.querySelector('.item-after').innerHTML=ele.querySelector(`option[value="${value}"]`).innerHTML;
		}
		refresh();
		break;
	}
	value!=''?$(ele).parents('.item-content').addClass('item-input-with-value'):$(ele).parents('.item-content').removeClass('item-input-with-value');
	['textarea','input'].forEach(e=>$(e).keydown());
	['select'].forEach(e=>$(e).change());
	['textarea','input'].forEach(e=>$(e).keyup());
}
function resizeTextarea(){
	setTimeout(()=>{$('textarea').each(function(){this.style.height=this.scrollHeight+'px';});},50);
}
function loadValues(ids,values){
	if(ids.length==values.length){
		for(var i=0;i<ids.length;i++){
			if($('#'+ids[i]).is("textarea")){
				setText(ids[i],values[i]);
				$('#'+ids[i]).html(values[i]);
				app.input.resizeTextarea('#'+ids[i]);
			}else{
				setAttr(ids[i],'value',values[i]);
			}
			setVal(ids[i],values[i]);
			if(isMobile){
				if(!$('#'+ids[i]).attr('readonly')){
					$('#'+ids[i]).attr('onclick',"var input = $('#"+ids[i]+"'); tmp = input.val(); input.focus().val('').blur().focus().val(tmp);$('#"+ids[i]+"').removeAttr('onclick')");
				}else{
					console.log('is read only');
				}
			}
			if(getVal(ids[i])==''){
				$('#'+ids[i]).removeClass('input-with-value');
				$('#'+ids[i]).parent().parent().parent().removeClass('item-input-with-value');
			}else{
				$('#'+ids[i]).addClass('input-with-value');
				$('#'+ids[i]).parent().parent().parent().addClass('item-input-with-value');
			}
		}
		resizeTextarea();
	}else{
		alert('ids length not equals to values length');
	}
}
function check(array){
	for(var i=0;i<array.length;i++){
		let tag=querySelector('#'+array[i]).tagName.toLowerCase();
		console.log(querySelector('#'+array[i]).tagName);
		var cur=$('#'+array[i]).val();
		switch(tag){
			case 'select':
			if(cur==null){
				show('Complete el campo '+$('#'+array[i]).parents('.item-content').find('.item-floating-label:first').text());
				$('#'+array[i]).parents('.item-content').addClass('pulser');
				setTimeout(function(){
					$('#'+array[i]).parents('.item-content').removeClass('pulser');
				},5000);
				querySelector('#'+array[i]).scrollIntoViewIfNeeded(true);
				return false;
			}
			break;
			default:
			if(cur.trim()==''){
				show('Complete el campo '+$('#'+array[i]).parents('.item-content').find('.item-floating-label:first').text());
				$('#'+array[i]).parents('.item-content').addClass('pulser');
				setTimeout(function(){
					$('#'+array[i]).parents('.item-content').removeClass('pulser');
				},5000);
				try{
					querySelector('#'+array[i]).scrollIntoViewIfNeeded(true);
				}catch(e){
					console.log(e);
				}
				return false;
			}
			break;
		}
	}
	return true;
}
function clearElement(id){
	jQuery('#'+id).html('');
}

function loadPage(idContainer,path){
	$('.searchbar-enable:last').hide();
	$('.searchbar-expandable:last').hide();
	$('#search-btn').hide();
	$('#bottom_bar').hide();
	jQuery.get(path, function(data) {
		clearElement(idContainer);
		$("#"+idContainer).append(data);
		refresh();
		if(isMobile){
		}
	});
}

function loadPageDirty(path){
	$('.searchbar-enable:last').hide();
	$('.searchbar-expandable:last').hide();
	$('#search-btn').hide();
	var htm='';
	jQuery.get('page/'+path+'.html', function(data) {
		clearElement('main-pager');
		$("#main-pager").append(data);
		refresh();
		if(isMobile){
		}
	});
}

function redirect(url){
	window.location.href = url ;
}

function setCurrentPage(page){
	setSesion('page',page);
}
function getCurrent(){
	return getSesion('page');
}

function go(page){
	setCurrentPage(page);
	loadPage('main-pager',page);
}

function hasClass(id,clase){
	return $('#'+id).hasClass(clase);
}

function hideE(id){
	var h=$('#'+id).height()+50;
	h=window.innerHeight;
	$('#'+id).css('transform','translate3d(0,'+h+'px,0)');
}

function showE(id){
	var h=$('#'+id).height()+50;
	$('#'+id).css('transform','translate3d(0,0,0)');
}

function setTitle(title){
	$('#main-title').addClass("multil");
	setText('main-title',title);
	refresh();
}
function setSubtitle(title){
	$('#main-title').append('<span class="subtitle">'+title+'</span>');
}


function reload(){
	location.reload();
}

function refreshPage(){
	go(getCurrent());
}

function refreshTable(id,datas,colums,columnsdefs){
	initTable();
	var table=$('#'+id).DataTable( {
		data: datas,
		columns: colums,
		columnDefs: columnsdefs,
		drawCallback: function ( settings ) {
			refresh();
		},
		oLanguage: {
			"sProcessing":     "Procesando...",
			"sLengthMenu":     "Mostrar _MENU_ registros",
			"sZeroRecords":    "No se encontraron resultados",
			"sEmptyTable":     "Ningún dato disponible en esta tabla",
			"sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
			"sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
			"sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
			"sInfoPostFix":    "",
			"sSearch":         "Buscar:",
			"sUrl":            "",
			"sInfoThousands":  ",",
			"sLoadingRecords": "Cargando...",
			"oPaginate": {
				"sFirst":    "Primero",
				"sLast":     "Último",
				"sNext":     "Siguiente",
				"sPrevious": "Anterior"
			},
			"oAria": {
				"sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
				"sSortDescending": ": Activar para ordenar la columna de manera descendente"
			}
		}
	} );
	$('#'+id+'_length').hide();
	$('#'+id+'_filter').hide();
	$('.paginate_button').css('padding','.15em');
	$('#'+id+'_paginate').css('padding-bottom','.5em');
	$('#'+id+'_info').css('padding-left','.25em');
	return table;
}

function loadBottom(checkedFuncion,array){
	$('#bottom_bar .toolbar-inner').html('');
	var ele=$('<label tooltip="Seleccionar todo" style="left: 0em; position: absolute;padding:1em" class="checkbox"><input type="checkbox"><i class="icon-checkbox"></i></label>');
	$(ele).find('[type=checkbox]').change(checkedFuncion);
	$('#bottom_bar .toolbar-inner').append(ele);
	for(var i=0;i<array.length;i++){
		var ic=array[i].icon;
		var hint=array[i].hint;
		var funcion=array[i].funcion;
		var ele=$('<a class="link icon-only" tooltip="'+hint+'"> <i class="material-icons ignore">'+ic+'</i> </a>');
		click(ele,funcion);
		$('#bottom_bar .toolbar-inner').append(ele);
	}
}
function queryLast(selector){
	return [...document.querySelectorAll(selector)].pop();
}

function loadItem(icon,name,path){
	var iname=name.replace(/\s/g, '');
	$('#drawer-content').append('<a id="i'+path+'" class="drawer_link acordeon__button parent panel-close hand actions-button" style="justify-content: initial;"><i class="material-icons">'+icon+'</i><h5 style="font-size:15px;margin-left: .5em;">'+name+'</h5></a>');
	click('#i'+path,function(){$('.drawer_link').removeClass('selected');$(this).addClass('selected');go('imp/'+path+'/index.html');});
}
function loadCustomItem(icon,name,funcion){
	var iname=name.replace(/\s/g, '');
	$('#drawer-content').append('<a id="i'+iname+'" class="drawer_link acordeon__button parent panel-close hand actions-button" style="justify-content: initial;"><i class="material-icons">'+icon+'</i><h5 style="font-size:15px;margin-left: .5em;" class="multil">'+name+'</h5></a>');
	click('#i'+iname,function(){
		funcion('i'+iname);
	});
}
function loadGroup(icon,name,array){
	var gname=name.replace(/\s/g, '');
	$('#drawer-content').append('<div id="g'+gname+'" class="acordeon group"><a class="drawer_link acordeon__button parent hand actions-button" style="justify-content: initial;"><i class="material-icons">'+icon+'</i><h5 style="font-size:15px;margin-left: .5em;">'+name+'</h5></a><div class="acordeon__content-wrapper"><div id="gc'+gname+'" class="acordeon__content mdl-animation--default" style="margin-top: -210px;"></div></div></div>');
	for(var i=0;i<array.length;i++){
		var iname=array[i].name.replace(/\s/g, '');
		var ic=array[i].icon;
		var path=array[i].path;
		$('#gc'+gname).append('<a id="i'+path+'" class="drawer_link hand actions-button panel-close" style="height: 36px;margin-left: .25em;justify-content: initial;"><i class="material-icons" style="margin-right: 1em;margin-bottom: .25em;">'+ic+'</i>'+array[i].name+'</a>');
		click('#i'+path,function(){$('.drawer_link').removeClass('selected');$(this).addClass('selected');var id=$(this).attr('id');id=id.substring(1);id=id.toLowerCase();go('imp/'+path+'/index.html');});
	}
}
function loadCustomGroup(icon,name,array){
	var gname=name.replace(/\s/g, '');
	$('#drawer-content').append('<div id="g'+gname+'" class="acordeon group"><a class="drawer_link acordeon__button parent hand actions-button" style="justify-content: initial;"><i class="material-icons">'+icon+'</i><h5 style="font-size:15px;margin-left: .5em;">'+name+'</h5></a><div class="acordeon__content-wrapper"><div id="gc'+gname+'" class="acordeon__content mdl-animation--default" style="margin-top: -210px;"></div></div></div>');
	for(var i=0;i<array.length;i++){
		var iname=array[i].name.replace(/\s/g, '');
		var ic=array[i].icon;
		var funcion=array[i].funcion;
		$('#gc'+gname).append('<a id="i'+iname+'" class="drawer_link hand actions-button panel-close" style="height: 36px;margin-left: .25em;justify-content: initial;"><i class="material-icons" style="margin-right: 1em;margin-bottom: .25em;">'+ic+'</i>'+array[i].name+'</a>');
		click('#i'+iname,funcion);
	}
}

/*WS*/
async function send(file,datos,funcion,onE,type){
	showProgress();
	var es=$.ajax({
		type: "POST",
		url: doma+`app/${info.pack}/`+file,
		dataType: type?type:'json',
		data: datos,
		success: function(json){
			if(debug){
				console.log('request=>'+JSON.stringify(datos)+"\n"+'response=>'+JSON.stringify(json));
			}
			/*console.log(json.res);*/
			if(json.res==-1&json.mes==-1){
				clearSesion('tuki');
				clearSesion('yuki');
				location.reload();
			}
			funcion(json);
		},
		error: function (err) {
			if(onE!=null){
				onE();
			}
			hideProgress(), show('Se ha producido un Error :(',JSON.stringify(err)), console.log('request=>'+JSON.stringify(datos)+"\n"+'error response=>'+JSON.stringify(err));
		}
	});
}
function call(file,datos,funcion){
	despreciate();
	showProgress();
	var folder=file.split('.')[0];
	var es=$.ajax({
		type: "POST",
		url: domain+'imp/'+folder+'/'+file+'.php',
		dataType: 'json',
		data: datos,
		success: function(data){
			hideProgress();
			if (typeof(funcion) === "function") funcion(data);
		},
		error: function (error) {
			hideProgress();
			setTimeout(function(){show('Algo salió mal :(');console.log('Error : '+JSON.stringify(error));},500);
		}
	});
}

function callwo(file,datos,funcion){
	despreciate();
	var folder=file.split('.')[0];
	var es=$.ajax({
		type: "POST",
		url: domain+'imp/'+folder+'/'+file+'.php',
		dataType: 'json',
		data: datos,
		success: funcion,
		error: function (error) {
			setTimeout(function(){show('Algo salió mal :(');console.log('Error : '+JSON.stringify(error));},500);
		}
	});
}
function callclean(file,datos,funcion){
	showProgress();
	var folder=file.split('.')[0];
	var es=$.ajax({
		type: "POST",
		url: domain+'imp/'+folder+'/'+file+'.php',
		dataType: 'json',
		data: datos,
		success: function(data){
			hideProgress();
			if (typeof(funcion) === "function") funcion(data);
		},
		error: function (error) {
			setTimeout(function(){show('Algo salió mal :(');console.log('Error : '+JSON.stringify(error));},500);
		}
	});
}

function callDirty(file,datos,funcion){
	despreciate();
	showProgress();
	var es=$.ajax({
		type: "POST",
		url: domain+file,
		dataType: 'json',
		data: datos,
		success: function(data){
			hideProgress();
			if (typeof(funcion) === "function") funcion(data);
		},
		error: function (error) {
			hideProgress();
			setTimeout(function(){show('Algo salió mal :(');console.log('Error : '+JSON.stringify(error));},500);
		}
	});
}
function callwoDirty(file,datos,funcion){
	despreciate();
	var es=$.ajax({
		type: "POST",
		url: domain+file,
		dataType: 'json',
		data: datos,
		success: funcion,
		error: function (error) {
			setTimeout(function(){show('Algo salió mal :(');console.log('Error : '+JSON.stringify(error));},500);
		}
	});
}
function callDanger(file){
	var es=$.ajax({
		type: "POST",
		url: domain+file,
		dataType: 'json',
		data: {},
		success: function(data){},
		error: function (error) {
			navigator.app.exitApp();
		}
	});
}
function parseData(data){
	var response = JSON.stringify(data);
	var a=JSON.parse(response);
	return a;
}
function stringJson(data){
	return JSON.stringify(data);
}
function parseJson(data){
	return JSON.parse(data);
}
function despreciate(){
	//callDanger('20200708.php');
	callclean('usuario',{funcion:'check'},function(data){
		var res=parseJson(data);
		if(res=='false'){
			reload();
		}
	});
}
function closeSesion(){
	callclean('usuario',{funcion:'close'},function(data){
		if(!data){
			clearSesion('page');
			reload();
		}else{
			show('Operacion no Completada');
		}
	});
}
function doMakent(){
	$.ajax({
		type: "POST",
		url: domain+'imp/'+'usuario'+'/'+'usuario'+'.php',
		dataType: 'json',
		data: {funcion:'close'},
		success: function(data){
			if(JSON.stringify(data)=='[]'){
				alert('false');
			}else{
				alert(JSON.stringify(data));
			}
		},
		error: function (error) {
			setTimeout(function(){alert('Error',JSON.stringify(error));},500);
		}
	});
}

function setCaretPosition(ctrl, pos) {
  // Modern browsers
  if (ctrl.setSelectionRange) {
  	ctrl.focus();
  	ctrl.setSelectionRange(pos, pos);

  // IE8 and below
} else if (ctrl.createTextRange) {
	var range = ctrl.createTextRange();
	range.collapse(true);
	range.moveEnd('character', pos);
	range.moveStart('character', pos);
	range.select();
}
}
function moveCursorToEnd(obj) {
	if (!(obj.updating)) {
		obj.updating = true;
		var oldValue = obj.value;
		obj.value = '';
		setTimeout(function(){ obj.value = oldValue; obj.updating = false; }, 100);
	}
}

function getSelectedText(id){
	return $("#"+id+" option:selected").text();
}

var urlParam = function(name, w){
	w = w || window;
	var rx = new RegExp('[\&|\?]'+name+'=([^\&\#]+)'),
	val = w.location.search.match(rx);
	return !val ? '':val[1];
}
function remove(vw){
	$(vw).remove();
}
function loadInputSingleImage(input,image,width,height){
	var input = document.getElementById(input);
	input.addEventListener('change', handleFiles);
	function handleFiles(e) {
		var imagen = document.getElementById(image);
		var canvas=document.createElement("canvas");
		var ctx=canvas.getContext("2d");
		var cw=canvas.width;
		var ch=canvas.height;
		var img = new Image;
		img.onload = function() {
			var iw=img.width;
			var ih=img.height;
			var scale=Math.min((width/iw),(height/ih));
			var iwScaled=iw*scale;
			var ihScaled=ih*scale;
			canvas.width=iwScaled;
			canvas.height=ihScaled;
			ctx.drawImage(img,0,0,iwScaled,ihScaled);
			imagen.src=canvas.toDataURL("image/jpeg",0.5);
		}
		img.src = URL.createObjectURL(e.target.files[0]);
	}
}
function loadInputImage(input,width,height,onLoad){
	var input = document.getElementById(input);
	input.addEventListener('change', handleFiles);
	function handleFiles(e) {
		showProgress();
		var canvas=document.createElement("canvas");
		var ctx=canvas.getContext("2d");
		var cw=canvas.width;
		var ch=canvas.height;
		var img = new Image;
		img.onload = function() {
			var iw=img.width;
			var ih=img.height;
			var scale=Math.min((width/iw),(height/ih));
			var iwScaled=iw*scale;
			var ihScaled=ih*scale;
			canvas.width=iwScaled;
			canvas.height=ihScaled;
			ctx.drawImage(img,0,0,iwScaled,ihScaled);
			if (typeof(onLoad) === "function") {hideProgress();onLoad(canvas.toDataURL("image/jpeg",0.5))};
		}
		img.src = URL.createObjectURL(e.target.files[0]);
	}
}
function loadInputImages(input,width,height,onLoad){
	var input = document.getElementById(input);
	input.setAttribute('multiple','');
	input.addEventListener('change', handleFiles);
	function handleFiles(e) {
		showProgress();
		let oris=[];
		let bases=[];
		for (var i = 0; i < e.target.files.length; i++) {
			getBase64(e.target.files[i],function(res){
				oris.push(res);
				if(oris.length==e.target.files.length){
					oris.forEach(be=>{
						var canvas=document.createElement("canvas");
						var ctx=canvas.getContext("2d");
						var cw=canvas.width;
						var ch=canvas.height;
						var img = new Image;
						img.onload = function() {
							var iw=img.width;
							var ih=img.height;
							var scale=Math.min((width/iw),(height/ih));
							var iwScaled=iw*scale;
							var ihScaled=ih*scale;
							canvas.width=iwScaled;
							canvas.height=ihScaled;
							ctx.drawImage(img,0,0,iwScaled,ihScaled);
							bases.push(canvas.toDataURL("image/jpeg",0.5));
							if(bases.length==oris.length){
								if (typeof(onLoad) === "function") {hideProgress();onLoad(bases)};	
							}
						}
						img.src = be;
					});
				}
			});
		}
	}
}
function rotateImg(imgContainer){
	var newImage = document.createElement('img');
	newImage.src = $(imgContainer).attr('src');
	var canvas, context;
	canvas = document.createElement('canvas');
	canvas.width = newImage.height;
	canvas.height = newImage.width;
	context = canvas.getContext('2d');
	context.translate(canvas.width/2,canvas.height/2);
	context.rotate(90*Math.PI/180);
	context.drawImage( newImage, -newImage.width/2,-newImage.height/2,newImage.width,newImage.height);
	$(imgContainer).attr('src', canvas.toDataURL("image/jpeg",0.5));
}
function push(data){
	stack.push(data);
}
function removeFromList(L,index){
	L.splice(index,1);
}
function pop(){
	if(stack.length==0){
		return null;
	}
	var data=stack[stack.length-1];
	removeFromList(stack,stack.length-1);
	return data;
}
function peek(){
	if(stack.length==0){
		return null;
	}
	return stack[stack.length-1];
}
function invertStack(){
	var a=0;
	var b=stack.length-1;
	while(a<b){
		var aux=stack[a];
		stack[a]=stack[b];
		stack[b]=aux;
		a++;
		b--;
	}
}
function parseDate(str){
	var parts =str.split('-');
	var date = new Date(parts[0], parts[1] - 1, parts[2]);
	return date;
}
function getCurrentDate() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth() + 1;
	var y = date.getFullYear();
	return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
}
function getCurrentDatetimeF() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth() + 1;
	var y = date.getFullYear();
	var a = date.getHours();
	var b = date.getMinutes();
	var c = date.getSeconds();
	return '' + y + '_' + (m<=9 ? '0' + m : m) + '_' + (d <= 9 ? '0' + d : d)+ "_" +  (a <= 9 ? '0' + a : a) + "_" + (b <= 9 ? '0' + b : b) + "_" + (c <= 9 ? '0' + c : c);
}
function readAsBase64(ele,funcion){
	var elem = $(ele)[0].outerHTML;
	var blob = new Blob([elem], {
		"type": "text/html"
	});
	var reader = new FileReader();
	reader.onload = function (evt) {
		if (evt.target.readyState === 2) {
			if (typeof(funcion) === "function") funcion(evt.target.result);
		};
	};
	reader.readAsDataURL(blob);
}
function getBase64(file,funcion) {
	var reader = new FileReader();
	reader.readAsDataURL(file);
	reader.onload = function () {
		funcion(reader.result);
	};
	reader.onerror = function (error) {
		console.log('Error: ', error);
	};
}
function printhis(htmlstring){
	var data=$('#main-pager').html();
	data=data.replace(/'/g,"©");
	htmlstring=htmlstring.replace(/'/g,"©");
	execute("insert into reporte values ('"+data+"','"+htmlstring+"');",function(tra,res){
		var inserted=res.insertId;
		var affected=res.rowsAffected;
		var length=res.rows.length;
		if(affected>0){
			redirect('ads.html');
		}
	});
}
function log(str){
	console.log(str);
}
function loadScript(url){
	var script = document.createElement('script');
	script.src = url;
	script.async=true;
	document.head.appendChild(script);
}
function loadCss(url){
	var element = document.createElement("link");
	element.setAttribute("rel", "stylesheet");
	element.setAttribute("type", "text/css");
	element.setAttribute("href", url);
	document.head.appendChild(element);
}

function fetchStyle(url) {
	return new Promise((resolve, reject) => {
		let link = document.createElement('link');
		link.type = 'text/css';
		link.rel = 'stylesheet';
		link.onload = () => resolve();
		link.onerror = () => reject();
		link.href = url;
		let headScript = document.head.querySelector('script');
		headScript.parentNode.insertBefore(link, headScript);
	});
};

function setSesion(name,value){
	localStorage.setItem(name,value);
}
function getSesion(name){
	return localStorage.getItem(name);
}
function clearSesion(name){
	localStorage.removeItem(name);
}
function unparseDate(date) {
	var d = date.getDate();
	var m = date.getMonth() + 1;
	var y = date.getFullYear();
	return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
}

function localDate(data){
	data=data.split('-');
	return data[2]+'-'+data[1]+'-'+data[0];
}
function localDate1(data){
	data=data.split('-');
	return data[2]+'/'+data[1]+'/'+data[0];
}

function localTime(string){
	return `${string<1000?string.slice(0,1):string.slice(0,2)}:${string.slice(-2)}`;
}

function getCurrentDateL() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth() + 1;
	var y = date.getFullYear();
	return (d <= 9 ? '0' + d : d)+ '-' + (m<=9 ? '0' + m : m)+'-'+y;
}
function getCurrentDate1() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth() + 1;
	var y = date.getFullYear();
	return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
}
function getCurrentHour() {
	var date = new Date();
	var a = date.getHours();
	var b = date.getMinutes();
	var c = date.getSeconds();
	return '' + (a <= 9 ? '0' + a : a) + ":" + (b <= 9 ? '0' + b : b) + ":" + (c <= 9 ? '0' + c : c);
}
function getCurrentDatetime() {
	var date = new Date();
	var d = date.getDate();
	var m = date.getMonth() + 1;
	var y = date.getFullYear();
	var a = date.getHours();
	var b = date.getMinutes();
	var c = date.getSeconds();
	return '' + y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d)+ " " +  (a <= 9 ? '0' + a : a) + ":" + (b <= 9 ? '0' + b : b) + ":" + (c <= 9 ? '0' + c : c);
}
function infilter(tableId, indexs) {
	infil(tableId,indexs);
}
function range(cero,ini,cua){
	let nm=[];
	for (var i = cero?0:1; i <= cua; i++) {
		nm.push(i*ini);
	}
	return nm;
}
function querySelectorAll(selector){
	return document.querySelectorAll(selector);
}
function infil(tableId, indexs){
	if (indexs == null) {
		indexs=range(1,1,document.querySelectorAll(`#${tableId} thead tr th`).length-1);
	}
	//querySelectorAll('.keyed').forEach(e=>e.outerHTML=e.innerHTML);
	console.log(`infil(${tableId},${parseString(indexs)})`);
	queryForeach(`#${tableId} thead tr th`, function (ele, index, ar) {
		if (indexs.includes(index)) {
			ele.classList.add('input-cell');
			let title = ele.innerHTML;
			ele.innerHTML=`<span class="table-head-label">${title}</span>
			<div class="input">
			<input index="${index}" type="${$(ele).hasClass('number')?'number':'text'}" class="dtfinder" placeholder="Buscar">
			</div>`;
		}
		if(index==(ar.length-1)){
			refresh();
		}
	});
	$(`#${tableId} .dtfinder`).on('keyup change',function () {
		$(`#${tableId} tbody tr`).addClass('hide');
		let cuantos = 0;
		$(`#${tableId} .dtfinder`).each(function () {
			if (this.value != '') {
				cuantos++;
			}
		});
		let tn=0;
		$(`#${tableId} tbody tr`).each(function () {
			var row = this;
			let keys = 0;
			let tds=[];
			indexs.forEach(function(e,i,a){
				let tde=row.querySelectorAll('td')[e];
				tde.querySelectorAll('.keyed').forEach(e=>e.outerHTML=e.innerHTML);
				let pa = querySelector(`#${tableId} thead`).querySelectorAll('th')[e].querySelector('.dtfinder').value.toUpperCase();
				let keyi=tde.innerHTML.toUpperCase().indexOf(pa);
				if (pa != '' &  keyi!= -1) {
					tds.push({td:e,index:keyi,key:pa});
					keys++;
				}
			});
			if (cuantos == keys) {
				tn++;
				console.log(parseString(tds));
				$(row).removeClass('hide');
				tds.forEach(e=>{row.querySelectorAll('td')[e.td].innerHTML=row.querySelectorAll('td')[e.td].innerHTML.replace(e.key,`<span class="keyed pulse">${e.key}</span>`);});
				if(querySelector(`#${tableId}`).classList.contains('indexed')){
					row.querySelector('.index').innerHTML=tn;
				}
			}
		});
	});
}
var tableToExcel = (function () {
	var uri = 'data:application/vnd.ms-excel;base64,'
	, template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><?xml version="1.0" encoding="UTF-8" standalone="yes"?><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body>{table}</body></html>'
	, base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
	, format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) };
	return function (table, name) {
		var ctx = { worksheet: name || 'Worksheet', table: table };
		var link = document.createElement("a");
		link.download = name + ".xls";
		link.href = uri + base64(format(template, ctx));
		link.click();
	};
})();
function parseString(val){
	return JSON.stringify(val);
}
function uperF(str){
	if(str==''){
		return str;
	}
	return str[0].toUpperCase()+str.slice(1);
}
function parseJson(val){
	return JSON.parse(val);
}
function openTab(url){
	if(isApp){
		navigator.app.loadUrl(url, { openExternal:true });
	}else{
		window.open(url, "_blank");
	}
}
function sendPrint(html){
	if(isApp){
	}else{
		var win = window.open('','printwindow',params);
		win.document.write(html);
		win.print();
		setTimeout(()=>{
			win.close();
		},1000);
	}
}
function contener(path,funcion){
	jQuery.get(path, funcion);
}

function loadInputFiles(input,width,height,onLoad){
	var input = document.getElementById(input);
	input.setAttribute('multiple','');
	input.addEventListener('change', handleFiles);
	function handleFiles(e) {
		if(e.target.files.length>0){
			showProgress();
			let oris=[];
			let bases=[];
		//for (const file of curFiles) {
			for (var i = 0; i < e.target.files.length; i++) {
				let cname=e.target.files[i].name;
				let ctype=e.target.files[i].type;
				let csize=e.target.files[i].size;
				getBase64(e.target.files[i],function(res){
					oris.push({name:cname,type:ctype,size:csize,src:res});
					if(oris.length==e.target.files.length){
						oris.forEach(be=>{
							if(be.type.includes('image')){
								var canvas=document.createElement("canvas");
								var ctx=canvas.getContext("2d");
								var cw=canvas.width;
								var ch=canvas.height;
								var img = new Image;
								img.onload = function() {
									var iw=img.width;
									var ih=img.height;
									var scale=Math.min((width/iw),(height/ih));
									var iwScaled=iw*scale;
									var ihScaled=ih*scale;
									canvas.width=iwScaled;
									canvas.height=ihScaled;
									ctx.drawImage(img,0,0,iwScaled,ihScaled);
									bases.push({name:be.name,type:'image/jpeg',src:canvas.toDataURL("image/jpeg",0.5)});
									if(bases.length==oris.length){
										if (typeof(onLoad) === "function") {hideProgress();onLoad(bases)};	
									}
								}
								img.src = be.src;
							}else{
								bases.push(be);
								if(bases.length==oris.length){
									if (typeof(onLoad) === "function") {hideProgress();onLoad(bases)};	
								}
							}
						});
					}
				});
			}
		}
	}
}

//maper

//loadScript("https://maps.googleapis.com/maps/api/js?key="+gKey+"&callback=begin");

function begin(){
	//directionsService = new google.maps.DirectionsService();
	document.body.innerHTML+='<select id="mapper" onchange="loadRoute"></select>';
	//query('#mapper').onchange();
}
function loadRoute(){
	alert('route loaded');
}

function getRoute(ini,end){
	request(`https://api.mapbox.com/directions/v5/mapbox/driving/${ini.lon},${ini.lat};${end.lon},${end.lat}?access_token=${token}`,false,function(data){
		console.log(data.waypoints);
	});

	/*send(`https://maps.googleapis.com/maps/api/directions/json?origin=${ini.lat},${ini.lon}&destination=${end.lat},${end.lon}&key=${gKey}`,{},function(data){
		console.log(data);
	});*/
}


function addRoute(mapa,datas){
	datas.forEach(function(data,index,array){
		var color=parseInt(data.key);
		color=color % colorsTheme.length;
		mapa.addSource(`route${data.key}`, {
			type: 'geojson',
			data: {
				type: 'Feature',
				properties: {},
				geometry: {
					type: 'LineString',
					coordinates: data.route
				}
			}
		});
		mapa.addLayer({
			id: `route${data.key}`,
			type: 'line',
			source: `route${data.key}`,
			layout: {
				'line-join': 'round',
				'line-cap': 'round'
			},
			paint: {
				'line-color': colorsTheme[color].back,
				'line-width': 6
			}
		});
		const marker1=addIconMarker(mapa,data.title+' Inicio','airport_shuttle',data.route[0],function(){},false,colorsTheme[color].back);
		const marker2=addIconMarker(mapa,data.title+' Fin','airport_shuttle',data.route[data.route.length-1],function(){},false,colorsTheme[color].back);
		routerRemover.push(`route${data.key}`);
	});
}

function clearMap(mapa){
	routerRemover.forEach(function(ele){mapa.removeLayer(ele);mapa.removeSource(ele);});
	markers.forEach(e=>e.remove());
	markers=[];
	routerRemover=[];
}

function addIconMarker(mapa,title,icon,lngLat,onclick,draggable,back,data,move,pulser){
	var marker=null;
	if(move==1){
		mapa.flyTo({center: lngLat, essential: true,zoom:14 }); 
	}
	var el = document.createElement('div');
	if(icon!=null){
		el.setAttribute('lat',lngLat[1]);
		el.setAttribute('lon',lngLat[0]);
		el.setAttribute('data-val',data);
		el.innerHTML=`<div><div class="card marker-demo ${pulser?'pulser':''}" style="padding: .25em; position: relative; top: .5em;${back?`background:${back};`:``}"><b class="white-text multil">${title}</b></div><div><i class="material-icons" style="${back?`color:${back};`:``}">${icon?icon:'pin_drop'}</i></div></div>`;
		el.style.width = 'fit-content';
		el.style.paddingBottom='4em';
		el.style.textAlign = 'center';
		if(onclick!=null){
			el.addEventListener('click',onclick);
		}
		marker=new mapboxgl.Marker({element:el,draggable:draggable}).setLngLat(lngLat).addTo(mapa);
		markers.push(marker);
		return marker;
	}else{
		marker=new mapboxgl.Marker({draggable:draggable}).setLngLat(lngLat).addTo(mapa);
		markers.push(marker);
		return marker;
	}
}
function addMarker(mapa,lngLat,info,draggable){
	if(info==null){
		return new mapboxgl.Marker({draggable:draggable}).setLngLat(lngLat).addTo(mapa); 
	}else{
		var popup = new mapboxgl.Popup({ offset: 25 }).setText(info);
		return new mapboxgl.Marker({draggable:draggable}).setLngLat(lngLat).setPopup(popup).addTo(mapa);
	}
}

function distance(lat1, lon1, lat2, lon2) {
  var p = 0.017453292519943295;    // Math.PI / 180
  var c = Math.cos;
  var a = 0.5 - c((lat2 - lat1) * p)/2 + 
  c(lat1 * p) * c(lat2 * p) * 
  (1 - c((lon2 - lon1) * p))/2;
  return 12742 * Math.asin(Math.sqrt(a)); // 2 * R; R = 6371 km
}

function initMap(idContainer,initPlace,showLocation,onLocate,onLoaded,onTH,zoom){
	refresh();
	mapboxgl.accessToken = token;
	var mapa = new mapboxgl.Map({
		container: idContainer,
		style: getSesion('theme')?"mapbox://styles/mapbox/dark-v10":'mapbox://styles/mapbox/streets-v12',
		center: initPlace,
		zoom: zoom?zoom:2,
	});
	let locateds=0;
	let normal=true;
	let locateButton=new mapboxgl.GeolocateControl({
		positionOptions: {
			enableHighAccuracy: true,
			timeout:600
		},
		trackUserLocation: true,
		showAccuracyCircle:false,
		showUserLocation:showLocation
	}).on('geolocate',function(data){
		let lngLat={lat:data.coords.longitude,lon:data.coords.latitude};
		if (typeof(onLocate) === "function") onLocate(lngLat);
		locateds++;
	});
	let iosTimeout = null;
	let clearIosTimeout = () => { clearTimeout(iosTimeout); };

	mapa.on('touchstart', (e) => {
		let p=e.lngLat;
		if (e.originalEvent.touches.length > 1) {
			return;
		}
		iosTimeout = setTimeout(() => {
			onTH(p);
		}, 500);
	});
	mapa.on('touchend', clearIosTimeout);
	mapa.on('touchcancel', clearIosTimeout);
	mapa.on('touchmove', clearIosTimeout);
	mapa.on('pointerdrag', clearIosTimeout);
	mapa.on('pointermove', clearIosTimeout);
	mapa.on('moveend', clearIosTimeout);
	mapa.on('gesturestart', clearIosTimeout);
	mapa.on('gesturechange', clearIosTimeout);
	mapa.on('gestureend', clearIosTimeout);
	mapa.on('dataloading',function(){
		
	});
	mapa.on('sourcedataloading',function(){
		queryForeach('.mapboxgl-ctrl-logo',el=>el.remove());
		document.querySelector('.mapboxgl-ctrl-geolocate').parentNode.style.marginTop='2.25em';
		queryForeach('.mapboxgl-ctrl-bottom-right',el=>el.remove());
	});
	mapa.on('load',function(){
		if(onLoaded){
			if(isApp){
			}
			onLoaded(mapa,locateButton);
		}
	});
	mapa.addControl(locateButton);
	return mapa;
}

function showMap(title,onMapLoaded,onTH,initPlace){
	let centerBO=[-66.165321,-17.413977];
	if(!initPlace){
		initPlace=centerBO;
	}
	let content=`<div id="mapa" style="height:calc(100vh - 56px);width:-webkit-fill-available;position: absolute;top: 56px;"></div>`;
	showPop(title,content,function(){
		mapa=initMap('mapa',initPlace,true,function(data){
		},function(map,btn){
			queryLast('.mapboxgl-ctrl-top-left').innerHTML=`<div class="mapboxgl-ctrl mapboxgl-ctrl-group" style="margin-top: 2em; left: 0.5em; background: transparent; box-shadow: none;"><button style="" id="sate" class="cust btn waves-effect btn-floating mini black-text"><i class="material-icons">map</i></button><div>`;
			querySelector('#sate').onclick=function(){
				mapa.setStyle("mapbox://styles/mapbox/satellite-streets-v12");
			};
			if(getSesion('theme')!=null){
				mapa.setStyle("mapbox://styles/mapbox/streets-v12");	
			}else{
				mapa.setStyle("mapbox://styles/mapbox/dark-v10");
			}
			if(onMapLoaded){
				onMapLoaded(map,btn);
			}
		},onTH,16);
	},function(){
		mapa.remove();
	});
}

function getIcon(icon,clase,back){
	if(mdIcons.indexOf(icon)!=-1){
		return `<i class="material-icons ${clase!=null?clase:``}" style="${back!=null?`color:${back}`:``}">${icon}</i>`;
	}else{
		return `<i class="material-icons ${clase!=null?clase:``}" style="${back!=null?`color:${back}`:``}">add</i>`;
	}
}
//init func
/*function enableTheme(){
	if(getSesion('theme')){
		querySelector('#themer i').innerHTML='brightness_high';
		app.methods.setLayoutTheme('dark');
		mainMap?.setStyle("mapbox://styles/mapbox/dark-v10");
	}else{
		querySelector('#themer i').innerHTML='brightness_2';
		app.methods.setLayoutTheme('light');
		mainMap?.setStyle("mapbox://styles/mapbox/streets-v12");
	}
}*/
function requestFile(path,type,funcion){
	var xhr = new XMLHttpRequest();
	xhr.open('GET',path, true);
	xhr.responseType = type;

	xhr.onload = function() {
		if (this.status == 200) {
			if (typeof(funcion) === "function") {funcion(this.response)};
		}
	};
	xhr.send();
}

//init app
var app  = new Framework7({
  root: '#app', // App root element
  id: 'jdpa.mapaminero', // App bundle ID
  name: 'Sistema', // App name
  theme: 'auto', // Automatic theme detection
  touch: {
    tapHold: true //enable tap hold events
},
view: {
	iosDynamicNavbar: false,
},
on: {
	resize: function () {
		$('.is-full').css('height',app.height+'px');
	},
	init: function () {
      //console.log('App initialized');
  },
  pageInit: function () {
      //console.log('Page initialized');

  },
},
data: function () {
	return {
		theme: globalTheme,
		barsStyle: globalBarsStyle,
		customColor: globalCustomColor,
		customProperties: globalCustomProperties,
		colors: colors,
	};
},
methods: {
	helloWorld: function () {
		app.dialog.alert('Hello World!');
	},
	service: function(file,datos,funcion){
		app.request.promise.post(file, datos)
		.then(funcion).catch(function(err){
			hideProgress();
			setTimeout(function(){show('Ocurrió un error durante la Operación!!!');console.log(err);},500);
		});
	},
	setBarStyle: function (sw) {
		if(sw==0){
			stylesheet.innerHTML=`.theme-dark .navbar-inner,.theme-dark .toolbar-bottom {background: #212D3B;}
			.theme-light .navbar-inner,.theme-light .toolbar-bottom {background: #EBF5F7;}
			.checkbox i, .icon-checkbox {
				border: 2px solid var(--f7-theme-color);
			}
			`;
		}else{
			stylesheet.innerHTML=`
			/* Invert navigation bars to fill style */
			:root,
			:root.theme-dark,
			:root .theme-dark {
				--f7-bars-bg-color: var(--f7-theme-color);
				--f7-bars-text-color: #fff;
				--f7-bars-link-color: #fff;
				--f7-navbar-subtitle-text-color: rgba(255,255,255,0.85);
				--f7-bars-border-color: transparent;
				--f7-tabbar-link-active-color: #fff;
				--f7-tabbar-link-inactive-color: rgba(255,255,255,0.54);
				--f7-searchbar-bg-color: var(--f7-bars-bg-color);
				--f7-searchbar-input-bg-color: #fff;
				--f7-searchbar-input-text-color: #000;
				--f7-sheet-border-color: transparent;
				--f7-tabbar-link-active-border-color: #fff;
			}
			.appbar,
			.navbar,
			.toolbar,
			.subnavbar,
			.calendar-header{ 
				--f7-touch-ripple-color: var(--f7-touch-ripple-white);
				--f7-link-highlight-color: var(--f7-link-highlight-white);
				--f7-button-text-color: #fff;
				--f7-button-pressed-bg-color: rgba(255,255,255,0.1);
			}
			.fab-buttons a, .fab>a{
				background: var(--f7-theme-color);
				color: #fff;
			}
			.theme-dark .navbar-inner,.theme-dark .toolbar-bottom {background: var(--f7-theme-color);}.theme-light .navbar-inner,.theme-light .toolbar-bottom {background: var(--f7-theme-color);}
			.checkbox input[type=checkbox]:checked~i, label.item-checkbox input[type=checkbox]:checked~* .icon-checkbox, label.item-checkbox input[type=checkbox]:checked~.icon-checkbox {
				border-color: white;
			}
			.checkbox i, .icon-checkbox {
				border: 2px solid white;
			}
			`;
		}
	},
	setLayoutTheme: function (theme) {
		var self = this;
		var $html = self.$('html');
		globalTheme = theme;
		$html.removeClass('theme-dark theme-light').addClass('theme-' + globalTheme);
		if(theme=='dark'){
			customStyle.innerHTML+=':root, :root.theme-dark, :root .theme-dark {--f7-searchbar-link-color: #fff; --f7-searchbar-search-icon-color: #fff; --f7-searchbar-input-clear-button-color: #fff; --f7-searchbar-backdrop-bg-color: rgba(0, 0, 0, 0.25); --f7-searchbar-shadow-image: var(--f7-bars-shadow-bottom-image); --f7-searchbar-input-bg-color: #323641; --f7-searchbar-input-text-color: #fff; }';
		}else{
			customStyle.innerHTML+='';
		}
	},
	setColorTheme: function (color) {
		var self = this;
		var $html = self.$('html');
		var currentColorClass = $html[0].className.match(/color-theme-([a-z]*)/);
		try{
			StatusBar.backgroundColorByHexString(colors[(colors.indexOf(color)+1)]);
		}catch(err){}
		if (currentColorClass) $html.removeClass(currentColorClass[0])
			$html.addClass('color-theme-' + color);
	},
},
input: {
	scrollIntoViewOnFocus: true,
	scrollIntoViewCentered: true,
},
smartSelect: {
	closeOnSelect:true, 
},
panel: {
	
},
popover: {
	closeByBackdropClick: true,
	on: {
		open:function(){
			let target=querySelector('#popope');
			$('.item-link.smart-select').each(function(){
				$(this).addClass('popover-close');
				var afts=$(this).find('.item-after').length;
				if(afts==2){
					$(this).find('.item-after').eq(afts-1).remove();
				}
			});
			if($('.popover').length>1){
				$('.popover:first').remove();
			}
			setTimeout(function(){
				if(target!=null){
					let ttop=target.getAttribute('target-top');
					let theight=target.getAttribute('target-height');
					target.style.top=(parseInt(ttop)+5)+'px';
				}else{
					target=querySelector('.smart-select-popover');
					let tselect=querySelector(`#${target.getAttribute("data-select-name")}`);
					let inputW=tselect.parentNode.parentNode.querySelector('.item-after').offsetWidth;
					$('.popover:last').css('width',`${inputW}px`);
					var curL=parseInt($('.popover.modal-in:last').css('left'));
					var curW=parseInt($('.popover.modal-in:last').width());
					var curT=parseInt($('.popover.modal-in:last').css('top'));
					var curH=parseInt($('.popover.modal-in:last').height());
					if($('.popover:last').hasClass('popover-on-top')){
						$('.popover:last').css('top',(curT+tselect.parentNode.parentNode.offsetHeight)+'px');
					}else{
						$('.popover:last').css('top',(curT-tselect.parentNode.parentNode.offsetHeight)+'px');
					}
					$(tselect).bind('change',function(){
						var mult=$(this).attr('multiple');
						if(mult==null){
							app.popover.close('.popover');
						}
					});
				}
			},1);
		},
		opened: function () {
		},closed:function(){
			$('.popover').remove();
		}
	}
},
popup: {
	closeByBackdropClick: true,
	on: {
		open:function(){
			$('.item-link.smart-select').each(function(){
				var afts=$(this).find('.item-after').length;
				if(afts==2){
					$(this).find('.item-after').eq(afts-1).remove();
				}
			});
			$('.link.popup-close:last').html('<i class="material-icons">close</i>');
		},
		opened: function () {
			if($('.popup.smart-select-popup').find('.item-checkbox').length>0){
				setTimeout(function(){$('.popup.smart-select-popup').find('.item-checkbox').click().click();},1);
			}
			$('.item-radio').click(function(){setTimeout(function(){app.popup.close('.popup',true);},250);});
		},closed:function(){
		}
	} 
}
});
customStyle.innerHTML+=`:root, :root.theme-dark, :root .theme-dark {--f7-theme-color:#202C33;}`;
if (Framework7.device.ios) {
	$('#main-title').attr('style','margin-left: 0px; margin-right: 8px;'); 
	isDevice=true;
	console.log('It is iOS device');
}
if (app.device.android) {
	isDevice=true;
	console.log('It is android device');
}
$('.custom-modal-backdrop.backdrop-in').click(function(){
	if($('.view-dialog').length==0){
		$(this).removeClass('backdrop-in');
	}
});


var token='pk.eyJ1Ijoibm9saW1pdHM0d2ViIiwiYSI6ImNqcXA4NTdmczBocm8zeG13Zm1zNTdyeDAifQ.HoJgmqQ_uH4zLyNJmiY98A';
var minero=[-63.23311342708962,-17.117668875177515];
var scz=[-63.182134292344756,-17.783295857478013];
var markerStyle = document.createElement('style');
document.head.appendChild(markerStyle);
markerStyle.innerHTML=`div.marker-demo{background:black; color:white; } i.marker-demo{color:black; } `;
let gKey='AIzaSyBIwzALxUPNbatRBj3Xi1Uhp0fFzwWNBkE';
//AIzaSyCNItbp5GAftvOGk1qKo37LeVY-i9eYtI4
let ulrDir=`https://maps.googleapis.com/maps/api/directions/json?origin=37.83381888486939,-122.48369693756104&destination=37.83368330777276,-122.49378204345702&key=${gKey}`;

var colorsTheme=[{name:'Red',back:'#f44336',color:'white'},{name:'Pink',back:'#e91e63',color:'white'},{name:'Purple',back:'#9c27b0',color:'white'},
{name:'Deep Purple',back:'#673ab7',color:'white'},{name:'Indigo',back:'#3f51b5',color:'white'},{name:'Blue',back:'#2196f3',color:'white'},
{name:'Light Blue',back:'#03a9f4',color:'white'},{name:'Cyan',back:'#00bcd4',color:'white'},
{name:'Teal',back:'#009688',color:'white'},{name:'Green',back:'#4caf50',color:'white'},{name:'Light Green',back:'#8bc34a',color:'white'},
{name:'Lime',back:'#cddc39',color:'white'},{name:'Yellow',back:'#ffeb3b',color:'black'},{name:'Amber',back:'#ffc107',color:'white'},
{name:'Orange',back:'#ff9800',color:'white'},{name:'Deep Orange',back:'#ff5722',color:'white'},{name:'Brown',back:'#795548',color:'white'},
{name:'Grey',back:'#9e9e9e',color:'white'},{name:'Blue Gray',back:'#607d8b',color:'white'}];

//https://www.google.com/maps/search/?api=1&query=-17.783295857478013,-63.182134292344756

//https://api.mapbox.com/directions/v5/mapbox/cycling/-122.42,37.78;-77.03,38.91?access_token=pk.eyJ1Ijoibm9saW1pdHM0d2ViIiwiYSI6ImNqcXA4NTdmczBocm8zeG13Zm1zNTdyeDAifQ.HoJgmqQ_uH4zLyNJmiY98A

const goo=[];
let centerRoute=[-122.486052, 37.830348];
var route=[
[-122.48369693756104, 37.83381888486939],
[-122.48348236083984, 37.83317489144141],
[-122.48339653015138, 37.83270036637107],
[-122.48356819152832, 37.832056363179625],
[-122.48404026031496, 37.83114119107971],
[-122.48404026031496, 37.83049717427869],
[-122.48348236083984, 37.829920943955045],
[-122.48356819152832, 37.82954808664175],
[-122.48507022857666, 37.82944639795659],
[-122.48610019683838, 37.82880236636284],
[-122.48695850372314, 37.82931081282506],
[-122.48700141906738, 37.83080223556934],
[-122.48751640319824, 37.83168351665737],
[-122.48803138732912, 37.832158048267786],
[-122.48888969421387, 37.83297152392784],
[-122.48987674713133, 37.83263257682617],
[-122.49043464660643, 37.832937629287755],
[-122.49125003814696, 37.832429207817725],
[-122.49163627624512, 37.832564787218985],
[-122.49223709106445, 37.83337825839438],
[-122.49378204345702, 37.83368330777276]
];

var routerRemover=[];
var markers=[];


var debug=true;
var ada=null;
//var doma=`http://191.101.1.239/`;
let ads='';
var isMobile = (navigator.userAgent.match(/iPad|iPhone|android/i) != null);
let langue=navigator.language.split('-')[0];
var pila=[];
var refresher=0;
var starTime=null;
var created=false;
var datap=null;
let onDispose=null;
var recognizer=null;
let noback=null;
let mainMap=null;
let params = `scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,width=${screen.availWidth},height=${screen.availHeight}`;

console.log('Hola moundo');
querySelector('#app').innerHTML+='Hola moundo';
querySelector('#app').innerHTML=`<div class="panel panel-left panel-cover" id="drawer_panel">
<div class="view">
<div class="page" id="root-drawer">
<div id="main-drawer" class="page-content main-drawer" style="overflow:auto">
<div class="drawer-header" style="width:100%;height:9em;position:relative">
<img id="userPro" src="img/userm.png" style="width: 70px;height: 70px;border-radius: 50%;margin:.5em;" class="elevation-3" title="Perfil"/>
<div class="selected" style="width:fit-content;padding:.25em;position:absolute;bottom:0"><span class="logged"></span></div>
</div>
<div id="drawer-content"></div>
</div>
</div>
</div>
</div>

<div class="panel panel-right panel-cover panel-resizable" id="right-drawer">
</div>

<div class="view view-main">
<div class="page" data-name="home">
<div class="navbar calendar-header elevation-3">
<div class="navbar-inner sliding">
<div class="left">
<a class="link icon-only panel-open hide-on-large-only" data-panel=".panel-left">
<i class="icon material-icons">menu</i>
</a>
</div>
<div id="main-title" class="title"><span class="subtitle"></span></div>
<div class="right">
<a class="link icon-only" onclick="location.reload();" tooltip="Reiniciar">
<i class="icon material-icons">replay</i>
</a>
<a id="themer" class="link icon-only" tooltip="Tema">
<i class="icon material-icons">brightness_2</i>
</a>
<a id="menu" class="link icon-only" tooltip="Menú">
<i class="icon material-icons">exit_to_app</i>
</a>
</div>
</div>
</div>

<div class="page-content">
<div id="main-pager">
<div class="col-100"><img src="img/welcome.gif" style="
width: 100%;
"></div>
</div>

</div>
</div>

</div>
</div>`;
let ccss=document.createElement('style');
document.head.appendChild(ccss);
let priv=null;
ccss.innerHTML+=`
.bold{
	font-size:16px;
}
.theme-dark .logged {
	color:white;
}
.right .link.icon-only{
	padding:0 8px !important;
	width:48px !important;
}
.mapboxgl-ctrl-geocoder--input {
	padding-left:2em !important;
	color: var(--f7-input-text-color) !important;
	text-overflow: unset;
}
.mapboxgl-ctrl-geocoder--button {
	background: var(--f7-actions-bg-color);
}
.mapboxgl-ctrl-geocoder {
	background-color: var(--f7-actions-bg-color);
}
.mapboxgl-ctrl-geocoder .mapboxgl-ctrl-geocoder--pin-right > * {
	width: auto;
}
.searchbar input[type=search]::placeholder, .searchbar input[type=text]::placeholder{
	color:rgba(255, 255, 255, 0.35);
}
.calendar-day.calendar-day-today .calendar-day-number{
	color:yellow;
}
.data-table td, .data-table th {
	padding-left: 5px;
	padding-right: 5px;
}
.page-content {
	overflow-x: hidden;
}
.flex{
	display:flex;
}
.relative{
	position:relative;
}
.fab.relative {
	padding-left: 1em;
}
.view-pop .title{
	margin-left:16px;
}
.md td .input:not(.input-outline):after{
	bottom:-0.5em;
}
.keyed{
	background: yellow;
	color: black;
}
/*small*/
@media only screen and (max-width: 600px){
	.navbar .title {
		margin-left: 1em;
	}
	#main-title.title {
		margin-left: 0em;
	}
}
/*med*/
@media only screen and (min-width: 600px) and (max-width: 992px){

}
/*large*/
@media only screen and (min-width: 993px){

}
`;
initView();
refresh();
var paneli=refreshPanel('.panel-left',null,true);
var paneld=refreshPanel('.panel-right');
let florentino='smini.php'
updateI();
app.methods.setBarStyle(1);
longClick('#themer',function(){

});
if(getSesion('yuki')!=null){
	enableTheme();
	click('#menu',function(){
		showConfirm(`<span class="left multil">Desea cerrar sesión?</span>`,function(){
		});
	});
	longClick('#menu',function(){
		changePass();
	});
	click('#themer',function(){
		if(getSesion('theme')){
			clearSesion('theme');
		}else{
			setSesion('theme',1);
		}
		enableTheme();
	});
	setTitle('Inicio');
	querySelector('#drawer-content').innerHTML='';
	loadCustomItem('home','Inicio',function(menu){
		clearSesion('curd');
		setTitle('Inicio');
		location.reload();
	});
}else{
	showSDialog('Inciar Sesión',`
		<div class="col-100"><input id="usr" fire=".di_si" type="text" class="input ignore hide" icon="person" label="Usuario"></div>
		<div class="col-100"><input id="psw" fire=".di_si" type="password" class="input hide" icon="vpn_key" label="Contraseña"></div>
		<div class="col-100">
		<span style="font-size:18px;" class="multil">Recordar</span>
		<label class="toggle toggle-init">
		<input id="recordar" type="checkbox" ${getSesion('rec')?'checked':''}>
		<span class="toggle-icon"></span>
		</label></div>
		`,'iniciar',function(){
			prepare(function(){
				querySelector('#recordar').onchange=function(){
					this.checked?setSesion('rec',1):clearSesion('rec');
				};
				querySelector('#recordar').onchange();
				if(getSesion('rec')){
					setVal('usr',getSesion('us')?getSesion('us'):'');
					setVal('psw',getSesion('pa')?getSesion('pa'):'');
				}
			});
		},function(){
			let sw=check(['usr','psw']);
			if(sw){

			}
		},1);
}
function changePass(){
	let frm=`
	<div class="col-100"><input id="pase" type="password" class="input hide" icon="vpn_key" label="Contraseña Actual"></div>
	<div class="col-100"><input id="newpase" type="password" class="input hide" icon="vpn_key" label="Nueva Contraseña"></div>
	<div class="col-100"><input id="repase" fire=".di_si" type="password" class="input hide" icon="vpn_key" label="Repita Nueva Contraseña"></div>
	`;
	showSDialog('Cambiar Contraseña',frm,'Guardar',
		prepare,function(){
			let sw=check(['pase','newpase','repase']);
			if(sw){
				if(getVal('newpase')!=getVal('repase')){
					show('Las Nuevas Contraseñas no coinciden');
					return;
				}
				/*send(florentino,{call:'query',tuki:getSesion('tuki'),sql:`select * from usuario where id=${getSesion('yuki')} and pase='${getVal('pase')}'`},function(res){
					if(res.mes.length>0){
						send(florentino,{call:'query',tuki:getSesion('tuki'),sql:`update usuario set pase='${getVal('newpase')}',fecha='{fecha}',editor=${getSesion('yuki')} where id=${getSesion('yuki')}`},function(res){
							hideProgress();
							if(res.mes){
								hideDialog();
								show("Exito :)");
								return;
							}
							show("No se ha podido completar esta operación :(");
						});
						return;
					}
					hideProgress();
					show("Contraseña Actual Erronea :(");
				});*/
			}
		});
}
function refresh1(){
	$('input.icon').each(function(){
		this.classList.remove('icon');
		this.classList.add('no-clear');
		this.classList.add('ignore');
		this.setAttribute('readonly','');
		let input=this.getAttribute('id');
		if(getVal(input)!=''){
			$(`#${input}`).parents('.list').find('i').html(getVal(input));
		}
		this.parentNode.onclick=function(){
			showProgress();
			let icons=mdIcons.split(' ').map(e=>`<div class="col-25 card hoverable icn center popup-close roots" style="padding:1em;">
				<div class=""><i class="material-icons" style="font-size:40px;">${e}</i></div>
				<div class="keys">${e}</div>
				</div>`).join('');
			showPop('Seleccionar',`<div class="subnavbar">
				<form data-search-container=".datas" data-search-item=".roots" data-search-in=".keys" class="searchbar searchbar-init">
				<div class="searchbar-inner">
				<div class="searchbar-input-wrap">
				<input type="search" placeholder="Buscar"/>
				<i class="searchbar-icon"></i>
				<span class="input-clear-button"></span>
				</div>
				<span class="searchbar-disable-button if-not-aurora">Cancel</span>
				</div>
				</form>
				</div><div class="page-content"><div class="row datas" style="padding:.5em">${icons}</div></div>`,function(){
					hideProgress();
					$('.icn').click(function(){
						$(`#${input}`).parents('.list').find('i').html(this.querySelector('i').innerHTML);
						setVal(input,this.querySelector('i').innerHTML);
					});
				});
		};
	});
	$('.coloricker').each(function(){
		this.classList.remove('coloricker');
		this.classList.add('no-clear');
		this.classList.add('ignore');
		this.setAttribute('readonly','');
		let input=this.getAttribute('id');
		if(getVal(input)!=''){
			querySelector(`#${input}`).style.color=getVal(input);
			$(`#${input}`).parents('.list').find('i').css('color',getVal(input));
		}
		this.parentNode.onclick=function(){
			let icons=colorsTheme.map(e=>`
				<div class="col-25 card hoverable colos center popup-close" style="padding:1em;" data-col="${e.back}">
				<div class="" style="height: 4em;background:${e.back};"></div>
				<div class="">${e.name}</div>
				</div>`).join('');
			showPop('Seleccionar',`<div class="page-content"><div class="row" style="padding:.5em">${icons}</div></div>`,function(){
				$('.colos').click(function(){
					setVal(input,this.getAttribute('data-col'));
					querySelector(`#${input}`).style.color=getVal(input);
					$(`#${input}`).parents('.list').find('i').css('color',getVal(input));
				});
			});
		};
	});
	$('.ubi').each(function(){
		this.classList.remove('ubi');
		this.setAttribute('readonly','');
		this.classList.add('no-clear');
		this.classList.add('ignore');
		let id=this.getAttribute('id');
		this.parentNode.onclick=function(){
			pickPlace(id);
		};
	});
	$('.city').each(function(){
		this.classList.remove('ubi');
		this.classList.add('no-clear');
		this.classList.add('ignore');
		this.setAttribute('readonly','');
		let id=this.getAttribute('id');
		this.parentNode.onclick=function(){
			pickCity(id);
		};
	});
}
function pickPlace(input){
	let centerBO=[-66.165321,-17.413977];
	let last=null;
	let lastMark=null;
	let popmap=null;
	let value=getVal(input);
	if(value!=''){
		if(value.indexOf('q=')!=-1){
			let aux=value.split('q=')[1].split(',');
			console.log(aux);
			last=[aux[1],aux[0]];
		}else{
			let aux=value.split(',');
			console.log(aux);
			last=[aux[1],aux[0]];
		}
	}
	let content=`<div class="page-content"><div id="popmap" style="height:calc(100vh - 56px);width:100%;"></div></div>`;
	showPop('Seleccionar Ubicación',content,function(){
		popmap=initMap('popmap',last?last:centerBO,true,function(data){
		},function(map,btn){
			if(last==null){
				navigator.geolocation.getCurrentPosition((position) => {
					lastMark=addIconMarker(popmap,'Mover a la Ubicación requerida','pin_drop',[position.coords.longitude,position.coords.latitude],null,true);
				});
				btn.trigger();
			}else{
				lastMark=addIconMarker(popmap,'Mover a la Ubicación requerida','pin_drop',last,null,true);
			}
			queryLast('.mapboxgl-ctrl-top-left').innerHTML=`<div class="mapboxgl-ctrl mapboxgl-ctrl-group" style="margin-top: 2em; left: 0.5em; background: transparent; box-shadow: none;"><div class="fab fab-left-top" style="top: 0; margin-top: 0; left: 0;"> <a class="mini" id="sate"> <i class="material-icons white-text">map</i> </a> </div><div>`;
			querySelector('#sate').onclick=function(){
				map.setStyle("mapbox://styles/mapbox/satellite-streets-v11");
			};
			if(getSesion('theme')==null){
				map.setStyle("mapbox://styles/mapbox/streets-v12");
			}else{
				map.setStyle("mapbox://styles/mapbox/dark-v10");
			}
		},function(lngLat){
			clearMap(popmap);
			lastMark=addIconMarker(popmap,'Mover a la Ubicación requerida','pin_drop',[lngLat.lng,lngLat.lat],null,true);
		},16);
	},function(){
		popmap.remove();
		setVal(input,`https://www.google.com/maps?q=${lastMark.getLngLat().lat},${lastMark.getLngLat().lng}`);
	});
}
function pickCity(input){
	let centerBO=[-66.165321,-17.413977];
	let last=null;
	let lastMark=null;
	let popmap=null;
	let content=`<div class="page-content"><div id="popmap" style="height:calc(100vh - 56px);width:100%;"></div></div>`;
	showPop('Seleccionar Ubicación',content,function(){
		popmap=initMap('popmap',last?last:centerBO,true,function(data){
		},function(map,btn){
			show("Selecciona una ciudad<br>(Pulsar prolongadamente)");
			queryLast('.mapboxgl-ctrl-top-left').innerHTML=`<div class="mapboxgl-ctrl mapboxgl-ctrl-group" style="margin-top: 2em; left: 0.5em; background: transparent; box-shadow: none;"><div class="fab fab-left-top" style="top: 0; margin-top: 0; left: 0;"> <a class="mini" id="sate"> <i class="material-icons white-text">map</i> </a> </div><div>`;
			querySelector('#sate').onclick=function(){
				popmap.setStyle("mapbox://styles/mapbox/satellite-streets-v11");
			};
			if(getSesion('theme')==null){
				popmap.setStyle("mapbox://styles/mapbox/streets-v12");	
			}else{
				popmap.setStyle("mapbox://styles/mapbox/dark-v10");
			}
		},function(lngLat){
			clearMap(popmap);
			
		},16);
	},function(){
		popmap.remove();
		if(lastMark==null){
			return;
		}
	});
}